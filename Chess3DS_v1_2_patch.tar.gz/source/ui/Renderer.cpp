#include "ui/Renderer.hpp"

#include <algorithm>
#include <cmath>

namespace chess3ds::ui {
namespace {

constexpr float BoardX = 40.0f;
constexpr float BoardY = 0.0f;
constexpr float SquareSize = 30.0f;

std::uint32_t withAlpha(std::uint32_t color, std::uint8_t alpha) {
    return (color & 0x00FFFFFFu) | (static_cast<std::uint32_t>(alpha) << 24u);
}

float ease(float value) {
    value = std::clamp(value, 0.0f, 1.0f);
    return value * value * (3.0f - 2.0f * value);
}

std::uint32_t mixAlpha(std::uint32_t color, float factor) {
    const auto alpha = static_cast<std::uint8_t>(std::clamp(factor, 0.0f, 1.0f) * 255.0f);
    return withAlpha(color, alpha);
}

} // namespace

bool Renderer::initialize() {
    top_ = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    bottom_ = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    textBuffer_ = C2D_TextBufNew(2048);
    return top_ && bottom_ && textBuffer_;
}

void Renderer::shutdown() {
    if (textBuffer_) C2D_TextBufDelete(textBuffer_);
    textBuffer_ = nullptr;
    top_ = nullptr;
    bottom_ = nullptr;
}

void Renderer::beginFrame() {
    C2D_TextBufClear(textBuffer_);
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
}

void Renderer::beginTop(std::uint32_t clearColor) {
    C2D_TargetClear(top_, clearColor);
    C2D_SceneBegin(top_);
}

void Renderer::beginBottom(std::uint32_t clearColor) {
    C2D_TargetClear(bottom_, clearColor);
    C2D_SceneBegin(bottom_);
}

void Renderer::endFrame() {
    C3D_FrameEnd(0);
}

void Renderer::text(const std::string& value, float x, float y, float scale,
                    std::uint32_t color, int flags, float wrapWidth) {
    C2D_Text parsed;
    C2D_TextParse(&parsed, textBuffer_, value.c_str());
    C2D_TextOptimize(&parsed);
    const std::uint32_t drawFlags = static_cast<std::uint32_t>(flags) | C2D_WithColor
        | (wrapWidth > 0.0f ? C2D_WordWrap : 0);
    if (wrapWidth > 0.0f)
        C2D_DrawText(&parsed, drawFlags, x, y, 0.8f, scale, scale, color, wrapWidth);
    else
        C2D_DrawText(&parsed, drawFlags, x, y, 0.8f, scale, scale, color);
}

void Renderer::panel(const Rect& rect, std::uint32_t color, float radius) {
    if (radius <= 0.0f) {
        C2D_DrawRectSolid(rect.x, rect.y, 0.2f, rect.w, rect.h, color);
        return;
    }
    const float r = std::min({radius, rect.w * 0.5f, rect.h * 0.5f});
    C2D_DrawRectSolid(rect.x + r, rect.y, 0.2f, rect.w - 2.0f * r, rect.h, color);
    C2D_DrawRectSolid(rect.x, rect.y + r, 0.2f, rect.w, rect.h - 2.0f * r, color);
    C2D_DrawCircleSolid(rect.x + r, rect.y + r, 0.2f, r, color);
    C2D_DrawCircleSolid(rect.x + rect.w - r, rect.y + r, 0.2f, r, color);
    C2D_DrawCircleSolid(rect.x + r, rect.y + rect.h - r, 0.2f, r, color);
    C2D_DrawCircleSolid(rect.x + rect.w - r, rect.y + rect.h - r, 0.2f, r, color);
}

void Renderer::button(const Rect& rect, const std::string& label, bool selected,
                      bool disabled, const Palette& colors, const std::string& hint) {
    const std::uint32_t fill = selected ? colors.accent : colors.panel;
    const std::uint32_t shadow = selected
        ? C2D_Color32(83, 123, 45, disabled ? 100 : 220)
        : C2D_Color32(22, 21, 20, disabled ? 80 : 190);

    panel({rect.x, rect.y + 3.0f, rect.w, rect.h}, shadow, 6.0f);
    panel(rect, disabled ? withAlpha(colors.panel, 145) : fill, 6.0f);

    const std::uint32_t textColor = disabled ? colors.muted : colors.text;
    text(label, rect.x + 12.0f, rect.y + 7.0f, 0.47f, textColor);
    if (!hint.empty())
        text(hint, rect.x + rect.w - 10.0f, rect.y + 8.0f, 0.40f,
             disabled ? colors.muted : (selected ? colors.text : colors.muted), C2D_AlignRight);
}

void Renderer::progressBar(const Rect& rect, float progress, std::uint32_t back,
                           std::uint32_t fill) {
    panel(rect, back, rect.h * 0.5f);
    progress = std::clamp(progress, 0.0f, 1.0f);
    if (progress > 0.0f)
        panel(Rect{rect.x, rect.y, rect.w * progress, rect.h}, fill, rect.h * 0.5f);
}

Palette Renderer::palette(platform::Theme theme) {
    // Default theme intentionally follows the visual language of modern
    // online chess clients: charcoal chrome, cream/green board, bright green
    // primary actions. All art is drawn locally and does not use third-party assets.
    switch (theme) {
        case platform::Theme::Midnight:
            return {C2D_Color32(30, 32, 34, 255), C2D_Color32(45, 48, 51, 255),
                    C2D_Color32(57, 61, 64, 255), C2D_Color32(242, 242, 242, 255),
                    C2D_Color32(164, 168, 171, 255), C2D_Color32(129, 182, 76, 255),
                    C2D_Color32(218, 79, 73, 255), C2D_Color32(222, 227, 230, 255),
                    C2D_Color32(111, 137, 150, 255), C2D_Color32(246, 246, 105, 170),
                    C2D_Color32(205, 210, 106, 170)};
        case platform::Theme::Forest:
            return {C2D_Color32(36, 35, 32, 255), C2D_Color32(49, 47, 43, 255),
                    C2D_Color32(60, 58, 53, 255), C2D_Color32(242, 242, 242, 255),
                    C2D_Color32(170, 168, 162, 255), C2D_Color32(129, 182, 76, 255),
                    C2D_Color32(218, 79, 73, 255), C2D_Color32(232, 235, 209, 255),
                    C2D_Color32(96, 133, 77, 255), C2D_Color32(246, 246, 105, 170),
                    C2D_Color32(205, 210, 106, 170)};
        case platform::Theme::Rosewood:
            return {C2D_Color32(38, 35, 32, 255), C2D_Color32(51, 47, 43, 255),
                    C2D_Color32(63, 58, 52, 255), C2D_Color32(244, 242, 238, 255),
                    C2D_Color32(173, 166, 158, 255), C2D_Color32(129, 182, 76, 255),
                    C2D_Color32(218, 79, 73, 255), C2D_Color32(240, 217, 181, 255),
                    C2D_Color32(181, 136, 99, 255), C2D_Color32(246, 246, 105, 170),
                    C2D_Color32(205, 210, 106, 170)};
        case platform::Theme::Classic:
        case platform::Theme::Count:
            return {C2D_Color32(38, 37, 34, 255), C2D_Color32(49, 46, 43, 255),
                    C2D_Color32(61, 58, 55, 255), C2D_Color32(242, 242, 242, 255),
                    C2D_Color32(167, 166, 162, 255), C2D_Color32(129, 182, 76, 255),
                    C2D_Color32(218, 79, 73, 255), C2D_Color32(238, 238, 210, 255),
                    C2D_Color32(118, 150, 86, 255), C2D_Color32(246, 246, 105, 175),
                    C2D_Color32(205, 210, 106, 175)};
    }
    return palette(platform::Theme::Classic);
}

Rect Renderer::boardRect() { return {BoardX, BoardY, SquareSize * 8.0f, SquareSize * 8.0f}; }

Rect Renderer::squareRect(int square, bool flipped) {
    if (!chess::validSquare(square)) return {};
    const int file = chess::fileOf(square);
    const int rank = chess::rankOf(square);
    const int screenFile = flipped ? 7 - file : file;
    const int screenRank = flipped ? rank : 7 - rank;
    return {BoardX + screenFile * SquareSize, BoardY + screenRank * SquareSize,
            SquareSize, SquareSize};
}

int Renderer::squareFromPoint(float x, float y, bool flipped) {
    if (!boardRect().contains(x, y)) return chess::NoSquare;
    const int screenFile = static_cast<int>((x - BoardX) / SquareSize);
    const int screenRank = static_cast<int>((y - BoardY) / SquareSize);
    const int file = flipped ? 7 - screenFile : screenFile;
    const int rank = flipped ? screenRank : 7 - screenRank;
    return rank * 8 + file;
}

void Renderer::board(const chess::Position& position, const Palette& colors, bool flipped,
                     int cursorSquare, int selectedSquare, const std::vector<chess::Move>& legalMoves,
                     const chess::Move* lastMove, const MoveAnimation& animation,
                     bool showLegalMoves) {
    C2D_DrawRectSolid(0, 0, 0.0f, 320, 240, colors.background);

    for (int square = 0; square < 64; ++square) {
        const Rect rect = squareRect(square, flipped);
        const bool light = ((chess::fileOf(square) + chess::rankOf(square)) & 1) != 0;
        C2D_DrawRectSolid(rect.x, rect.y, 0.1f, rect.w, rect.h,
                          light ? colors.lightSquare : colors.darkSquare);
    }

    if (lastMove) {
        for (int square : {static_cast<int>(lastMove->from), static_cast<int>(lastMove->to)}) {
            const Rect rect = squareRect(square, flipped);
            C2D_DrawRectSolid(rect.x, rect.y, 0.2f, rect.w, rect.h, colors.lastMove);
        }
    }

    if (chess::validSquare(selectedSquare)) {
        const Rect rect = squareRect(selectedSquare, flipped);
        C2D_DrawRectSolid(rect.x, rect.y, 0.3f, rect.w, rect.h, colors.selected);
    }

    const int checkedKing = position.inCheck(position.sideToMove())
        ? position.kingSquare(position.sideToMove()) : chess::NoSquare;
    if (checkedKing != chess::NoSquare) {
        const Rect rect = squareRect(checkedKing, flipped);
        C2D_DrawCircleSolid(rect.x + 15.0f, rect.y + 15.0f, 0.35f, 13.0f,
                            withAlpha(colors.danger, 180));
    }

    if (showLegalMoves && chess::validSquare(selectedSquare)) {
        for (const chess::Move& move : legalMoves) {
            const Rect rect = squareRect(move.to, flipped);
            if (move.isCapture()) {
                const std::uint32_t dot = mixAlpha(C2D_Color32(28, 28, 28, 255), 0.28f);
                C2D_DrawCircleSolid(rect.x + 15.0f, rect.y + 15.0f, 0.4f, 13.5f, dot);
                C2D_DrawCircleSolid(rect.x + 15.0f, rect.y + 15.0f, 0.41f, 9.6f,
                                    ((chess::fileOf(move.to) + chess::rankOf(move.to)) & 1)
                                        ? colors.lightSquare : colors.darkSquare);
            } else {
                C2D_DrawCircleSolid(rect.x + 15.0f, rect.y + 15.0f, 0.4f, 4.5f,
                                    mixAlpha(C2D_Color32(35, 35, 35, 255), 0.34f));
            }
        }
    }

    for (int square = 0; square < 64; ++square) {
        const chess::Piece value = position.pieceAt(square);
        if (!value) continue;
        if (animation.active && square == animation.move.to) continue;
        const Rect rect = squareRect(square, flipped);
        piece(value, rect.x + 1.0f, rect.y + 1.0f, rect.w - 2.0f);
    }

    if (animation.active) {
        const Rect from = squareRect(animation.move.from, flipped);
        const Rect to = squareRect(animation.move.to, flipped);
        const float t = ease(animation.progress);
        piece(animation.piece, from.x + 1.0f + (to.x - from.x) * t,
              from.y + 1.0f + (to.y - from.y) * t, SquareSize - 2.0f);
    }

    // Coordinates live inside the board, like modern online chess boards.
    for (int i = 0; i < 8; ++i) {
        const int file = flipped ? 7 - i : i;
        const int rank = flipped ? i : 7 - i;

        const char fileLabel[2] = {static_cast<char>('a' + file), '\0'};
        const bool bottomLight = ((file + (flipped ? 7 : 0)) & 1) != 0;
        const std::uint32_t fileColor = bottomLight ? colors.darkSquare : colors.lightSquare;
        text(fileLabel, BoardX + i * SquareSize + 2.0f, 226.0f, 0.27f, fileColor);

        const char rankLabel[2] = {static_cast<char>('1' + rank), '\0'};
        const bool leftLight = (((flipped ? 7 : 0) + rank) & 1) != 0;
        const std::uint32_t rankColor = leftLight ? colors.darkSquare : colors.lightSquare;
        text(rankLabel, BoardX + 2.0f, i * SquareSize + 2.0f, 0.27f, rankColor);
    }

    if (chess::validSquare(cursorSquare)) {
        const Rect rect = squareRect(cursorSquare, flipped);
        const std::uint32_t cursor = withAlpha(C2D_Color32(255, 255, 255, 255), 220);
        C2D_DrawRectSolid(rect.x + 0.5f, rect.y + 0.5f, 0.85f, rect.w - 1.0f, 1.4f, cursor);
        C2D_DrawRectSolid(rect.x + 0.5f, rect.y + rect.h - 1.9f, 0.85f, rect.w - 1.0f, 1.4f, cursor);
        C2D_DrawRectSolid(rect.x + 0.5f, rect.y + 0.5f, 0.85f, 1.4f, rect.h - 1.0f, cursor);
        C2D_DrawRectSolid(rect.x + rect.w - 1.9f, rect.y + 0.5f, 0.85f, 1.4f, rect.h - 1.0f, cursor);
    }
}

void Renderer::outlinedEllipse(float x, float y, float w, float h,
                               std::uint32_t outline, std::uint32_t fill, float border) {
    C2D_DrawEllipseSolid(x, y, 0.61f, w, h, outline);
    C2D_DrawEllipseSolid(x + border, y + border, 0.62f,
                         std::max(0.0f, w - border * 2.0f),
                         std::max(0.0f, h - border * 2.0f), fill);
}

void Renderer::outlinedRect(float x, float y, float w, float h,
                            std::uint32_t outline, std::uint32_t fill, float border) {
    C2D_DrawRectSolid(x, y, 0.61f, w, h, outline);
    C2D_DrawRectSolid(x + border, y + border, 0.62f,
                      std::max(0.0f, w - border * 2.0f),
                      std::max(0.0f, h - border * 2.0f), fill);
}

void Renderer::piece(chess::Piece value, float x, float y, float size, std::uint8_t alpha) {
    if (!value) return;

    const float s = size / 30.0f;
    auto X = [&](float vx) { return x + vx * s; };
    auto Y = [&](float vy) { return y + vy * s; };

    const bool white = value.color == chess::Color::White;
    const std::uint32_t outline = withAlpha(white
        ? C2D_Color32(82, 82, 78, 255)
        : C2D_Color32(28, 28, 27, 255), alpha);
    const std::uint32_t fill = withAlpha(white
        ? C2D_Color32(244, 244, 241, 255)
        : C2D_Color32(75, 74, 71, 255), alpha);
    const std::uint32_t detail = withAlpha(white
        ? C2D_Color32(124, 124, 119, 255)
        : C2D_Color32(25, 25, 24, 255), alpha);
    const std::uint32_t shadow = withAlpha(C2D_Color32(20, 20, 20, 255),
                                            static_cast<std::uint8_t>(alpha * 0.18f));
    const float b = std::max(0.8f, 1.05f * s);

    // Soft grounding shadow and a broad Staunton-style foot.
    C2D_DrawEllipseSolid(X(5.0f), Y(26.1f), 0.56f, 20.0f * s, 2.5f * s, shadow);

    auto foot = [&]() {
        outlinedEllipse(X(4.8f), Y(24.1f), 20.4f * s, 4.0f * s, outline, fill, b);
        outlinedRect(X(7.0f), Y(21.8f), 16.0f * s, 3.8f * s, outline, fill, b);
    };

    auto taperedBody = [&](float topX, float topY, float topW) {
        C2D_DrawTriangle(X(7.6f), Y(22.7f), outline,
                         X(22.4f), Y(22.7f), outline,
                         X(topX), Y(topY), outline, 0.60f);
        C2D_DrawTriangle(X(9.2f), Y(21.8f), fill,
                         X(20.8f), Y(21.8f), fill,
                         X(topX), Y(topY + 1.3f), fill, 0.62f);
        outlinedEllipse(X((30.0f - topW) * 0.5f), Y(topY - 0.2f),
                        topW * s, 3.2f * s, outline, fill, b * 0.8f);
    };

    switch (value.type) {
        case chess::PieceType::Pawn: {
            foot();
            taperedBody(15.0f, 12.2f, 10.0f);
            outlinedEllipse(X(10.2f), Y(4.4f), 9.6f * s, 9.6f * s, outline, fill, b);
            break;
        }

        case chess::PieceType::Rook: {
            foot();
            // Slightly tapered tower.
            C2D_DrawTriangle(X(8.2f), Y(22.6f), outline,
                             X(21.8f), Y(22.6f), outline,
                             X(10.0f), Y(9.5f), outline, 0.60f);
            C2D_DrawTriangle(X(9.8f), Y(21.6f), fill,
                             X(20.2f), Y(21.6f), fill,
                             X(11.2f), Y(10.8f), fill, 0.62f);
            C2D_DrawRectSolid(X(10.0f), Y(9.2f), 0.61f, 10.0f * s, 3.0f * s, outline);
            C2D_DrawRectSolid(X(11.0f), Y(10.1f), 0.62f, 8.0f * s, 2.0f * s, fill);
            outlinedRect(X(7.2f), Y(6.0f), 15.6f * s, 5.0f * s, outline, fill, b);
            for (float cx : {7.2f, 12.9f, 18.6f})
                outlinedRect(X(cx), Y(3.5f), 4.2f * s, 4.5f * s, outline, fill, b * 0.75f);
            break;
        }

        case chess::PieceType::Knight: {
            foot();
            // Neck/body.
            C2D_DrawTriangle(X(7.5f), Y(22.6f), outline,
                             X(22.2f), Y(22.6f), outline,
                             X(13.0f), Y(8.0f), outline, 0.60f);
            C2D_DrawTriangle(X(9.4f), Y(21.6f), fill,
                             X(20.1f), Y(21.6f), fill,
                             X(13.7f), Y(9.9f), fill, 0.62f);

            // Curved head illusion: cheek ellipse + long muzzle triangle.
            outlinedEllipse(X(10.4f), Y(6.3f), 11.5f * s, 10.0f * s, outline, fill, b);
            C2D_DrawTriangle(X(13.4f), Y(8.2f), outline,
                             X(23.3f), Y(12.0f), outline,
                             X(13.2f), Y(16.0f), outline, 0.64f);
            C2D_DrawTriangle(X(14.0f), Y(9.5f), fill,
                             X(21.1f), Y(12.1f), fill,
                             X(14.0f), Y(14.5f), fill, 0.66f);

            // Ear and mane line.
            C2D_DrawTriangle(X(11.5f), Y(7.2f), outline,
                             X(11.0f), Y(2.8f), outline,
                             X(16.0f), Y(6.1f), outline, 0.65f);
            C2D_DrawTriangle(X(12.3f), Y(6.5f), fill,
                             X(12.2f), Y(4.6f), fill,
                             X(14.5f), Y(6.0f), fill, 0.67f);
            C2D_DrawLine(X(11.2f), Y(8.4f), detail, X(9.4f), Y(17.8f), detail, 1.2f * s, 0.71f);
            C2D_DrawCircleSolid(X(16.2f), Y(9.3f), 0.73f, 1.05f * s, detail);
            break;
        }

        case chess::PieceType::Bishop: {
            foot();
            taperedBody(15.0f, 12.0f, 9.0f);
            outlinedEllipse(X(10.1f), Y(4.0f), 9.8f * s, 11.0f * s, outline, fill, b);
            // Mitre slit.
            C2D_DrawLine(X(12.4f), Y(13.0f), detail,
                         X(17.7f), Y(5.8f), detail, 1.5f * s, 0.74f);
            break;
        }

        case chess::PieceType::Queen: {
            foot();
            taperedBody(15.0f, 12.0f, 12.0f);
            // Crown bowl.
            C2D_DrawTriangle(X(8.2f), Y(13.8f), outline,
                             X(21.8f), Y(13.8f), outline,
                             X(9.5f), Y(6.6f), outline, 0.61f);
            C2D_DrawTriangle(X(9.8f), Y(12.8f), fill,
                             X(20.2f), Y(12.8f), fill,
                             X(10.7f), Y(7.9f), fill, 0.63f);
            for (float cx : {8.3f, 11.7f, 15.0f, 18.3f, 21.7f}) {
                const float cy = (cx == 15.0f) ? 3.0f : ((cx == 11.7f || cx == 18.3f) ? 4.0f : 5.2f);
                outlinedEllipse(X(cx - 1.55f), Y(cy), 3.1f * s, 3.1f * s, outline, fill, b * 0.65f);
            }
            break;
        }

        case chess::PieceType::King: {
            foot();
            taperedBody(15.0f, 12.5f, 10.5f);
            outlinedEllipse(X(10.1f), Y(8.2f), 9.8f * s, 7.5f * s, outline, fill, b);
            // Clean cross.
            outlinedRect(X(13.5f), Y(1.2f), 3.0f * s, 8.2f * s, outline, fill, b * 0.55f);
            outlinedRect(X(10.8f), Y(3.6f), 8.4f * s, 3.0f * s, outline, fill, b * 0.55f);
            break;
        }

        case chess::PieceType::None:
            break;
    }
}

void Renderer::logo(float centerX, float centerY, float size, const Palette& colors) {
    // A simple original knight tile using the same green/charcoal language.
    const Rect tile{centerX - size * 0.5f, centerY - size * 0.5f, size, size};
    panel({tile.x, tile.y + 4.0f, tile.w, tile.h}, C2D_Color32(72, 108, 39, 210), size * 0.16f);
    panel(tile, colors.accent, size * 0.16f);
    chess::Piece knight{chess::PieceType::Knight, chess::Color::White};
    piece(knight, tile.x + size * 0.10f, tile.y + size * 0.10f, size * 0.80f);
}

} // namespace chess3ds::ui
