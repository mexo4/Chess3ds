#include "engine/StockfishEngine.hpp"

#include "bitboard.h"
#include "endgame.h"
#include "position.h"
#include "search.h"
#include "thread.h"
#include "tt.h"
#include "uci.h"

#include <algorithm>
#include <atomic>
#include <array>
#include <deque>
#include <new>
#include <utility>

namespace PSQT { void init(); }

namespace chess3ds::engine {

namespace {

constexpr int MinElo = 400;
constexpr int MaxElo = 2600;

struct EloPreset {
    int elo;
    int skill;
    int thinkMs;
};

constexpr std::array<EloPreset, 12> EloPresets{{
    {400,  0,   20},
    {600,  1,   28},
    {800,  2,   40},
    {1000, 3,   55},
    {1200, 4,   75},
    {1400, 6,  105},
    {1600, 8,  150},
    {1800, 11, 220},
    {2000, 14, 330},
    {2200, 17, 500},
    {2400, 19, 760},
    {2600, 20, 1100},
}};

const EloPreset& presetForElo(int elo) {
    elo = std::clamp(elo, MinElo, MaxElo);
    const EloPreset* best = &EloPresets.front();
    for (const auto& preset : EloPresets) {
        if (std::abs(preset.elo - elo) < std::abs(best->elo - elo))
            best = &preset;
    }
    return *best;
}

} // namespace

struct StockfishEngine::Impl {
    bool initialized{false};
    bool initializationAttempted{false};
    std::atomic_bool thinking{false};
    ::Position position;
    StateListPtr states;
    Color searchSide{WHITE};
};

StockfishEngine::StockfishEngine() = default;
StockfishEngine::~StockfishEngine() { shutdown(); }

bool StockfishEngine::initialize() {
    if (!impl_) {
        impl_.reset(new (std::nothrow) Impl);
        if (!impl_) return false;
    }
    if (impl_->initialized) return true;
    if (impl_->initializationAttempted) return false;
    impl_->initializationAttempted = true;

    UCI::init(Options);
    PSQT::init();
    Bitboards::init();
    ::Position::init();
    Bitbases::init();
    Endgames::init();

    // ucioption.cpp uses 1 MiB hash and one thread for the embedded build.
    // Create the thread pool before touching options whose callbacks expect it.
    Threads.set(1);
    if (Threads.empty() || !TT.is_ready()) {
        if (!Threads.empty()) Threads.set(0);
        return false;
    }

    Options["SyzygyProbeLimit"] = std::string("0");
    Search::clear();

    impl_->initialized = true;
    return true;
}

void StockfishEngine::shutdown() {
    if (!impl_ || !impl_->initialized) return;
    stop();
    Threads.set(0);
    impl_->initialized = false;
}

bool StockfishEngine::isInitialized() const {
    return impl_ && impl_->initialized;
}

int StockfishEngine::clampElo(int elo) {
    return std::clamp(elo, MinElo, MaxElo);
}

int StockfishEngine::skillForElo(int elo) {
    return presetForElo(elo).skill;
}

int StockfishEngine::defaultThinkTimeMsForElo(int elo) {
    return presetForElo(elo).thinkMs;
}

bool StockfishEngine::start(const std::string& fen, int elo, int thinkTimeMs) {
    if (!impl_ || !impl_->initialized || impl_->thinking.load(std::memory_order_acquire)) return false;

    elo = clampElo(elo);

    // Stockfish 11 exposes a calibrated UCI_Elo range from 1350 upward.
    // Below that range use its built-in Skill Level weakening instead.
    if (elo >= 1350) {
        Options["UCI_LimitStrength"] = std::string("true");
        Options["UCI_Elo"] = std::to_string(std::clamp(elo, 1350, 2600));
        Options["Skill Level"] = std::string("20");
    } else {
        Options["UCI_LimitStrength"] = std::string("false");
        Options["Skill Level"] = std::to_string(skillForElo(elo));
    }

    impl_->states.reset(new std::deque<StateInfo>(1));
    impl_->position.set(fen, false, &impl_->states->back(), Threads.main());
    impl_->searchSide = impl_->position.side_to_move();

    Search::LimitsType limits;
    limits.startTime = now();
    limits.movetime = std::max(20, thinkTimeMs);

    impl_->thinking.store(true, std::memory_order_release);
    Threads.start_thinking(impl_->position, impl_->states, limits, false);
    return true;
}

bool StockfishEngine::poll(EngineResult& result) {
    if (!impl_ || !impl_->initialized) return false;
    if (!impl_->thinking.load(std::memory_order_acquire) || Threads.empty()
        || Threads.main()->is_searching()) return false;

    EngineResult completed;
    const MainThread* main = Threads.main();
    completed.depth = static_cast<int>(main->completedDepth);
    completed.nodes = Threads.nodes_searched();
    if (!main->rootMoves.empty() && !main->rootMoves.front().pv.empty()) {
        completed.bestMoveUci = UCI::move(main->rootMoves.front().pv.front(), false);
        int score = static_cast<int>(main->rootMoves.front().score);
        if (impl_->searchSide == BLACK) score = -score;
        completed.evaluationCp = std::clamp(score, -32000, 32000);
    }
    impl_->thinking.store(false, std::memory_order_release);
    result = std::move(completed);
    return true;
}

bool StockfishEngine::isThinking() const {
    return impl_ && impl_->initialized && impl_->thinking.load(std::memory_order_acquire);
}

void StockfishEngine::stop() {
    if (!impl_ || !impl_->initialized) return;
    if (impl_->thinking.load(std::memory_order_acquire)) {
        Threads.stop.store(true, std::memory_order_release);
        Threads.main()->wait_for_search_finished();
    }
    impl_->thinking.store(false, std::memory_order_release);
}

} // namespace chess3ds::engine
