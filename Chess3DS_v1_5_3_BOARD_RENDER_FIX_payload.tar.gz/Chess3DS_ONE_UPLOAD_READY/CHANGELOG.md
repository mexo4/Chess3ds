# Chess3DS Changelog

## v1.5.3
- Fixed the gameplay board being covered by the cream bezel.
- The 64 squares now render as the approved warm-cream / olive checkerboard.
- Changed only board rendering; pieces and the rest of the UI are unchanged.

## v1.5.2.2
- Fixed Nintendo 3DS texture build with tex3ds v2.3.0 by replacing shorthand options with long options.
- No visual or gameplay downgrade from v1.5.2.

## v1.5.2.2
- Rebuilt the gameplay visuals directly from the approved Concept A reference.
- Replaced the procedural chess-piece renderer with a 12-sprite raster atlas derived from the approved reference: white/black king, queen, rook, bishop, knight and pawn.
- Changed the gameplay board to the warm ivory/olive palette from the reference and moved a-h / 1-8 notation outside the board.
- Reworked the right-side player cards, avatars, clocks and last-move panel to closely match Concept A.
- Rebuilt the lower-screen piece gallery and touch controls to match the reference layout within the real 320x240 touch-screen limit.
- Gameplay screen now always uses the Concept A visual palette; menus retain their theme setting.

## v1.4
- Rebuilt the in-game layout to match the accepted Concept A: board on the upper-left, player cards and clocks on the upper-right.
- Added a full 12-piece gallery on the touch screen with white and black King, Queen, Rook, Bishop, Knight and Pawn.
- Added large touch controls for Menu, Undo, Hint, Settings and Resign.
- Moved square coordinates and cursor rendering to a scalable board renderer so the full 8x8 board fits the 400x240 upper screen cleanly.
- Added in-game Settings return flow so opening settings during a match no longer sends the player back to the main menu.
- Preserved D-pad + A board control because the Nintendo 3DS upper screen is not touch-sensitive.

## v1.3.1
- Draw result is checked immediately after every completed move.
- Threefold repetition automatically ends live games on the third occurrence.
- The 50-move rule automatically ends the game after 100 halfmoves without a pawn move or capture.
- Expanded Chess.com-style insufficient-material detection: K+B vs K+N, K+B vs K+B and K+2N vs lone K now draw correctly.
- Added regression tests for automatic draw detection and material edge cases.

## v1.3
- Rebalanced bot strength: 400-3000 ELO presets.
- 2900/3000 now disable Stockfish strength limiting and use full Skill 20.
- Increased high-end search budgets up to 12 seconds per move in unlimited games.
- Timed games now scale engine think time from remaining clock instead of hard-capping every move at 1.5 seconds.
- Increased embedded transposition table from 1 MiB to 2 MiB and worker stack to 1.5 MiB.
- Switched the 3DS release build from -O2 to -O3 for additional engine speed.

## v1.2.1
- Reworked the entire in-game piece set again with cleaner Chess.com-inspired Neo silhouettes.
- Increased contrast and highlights on both white and black pieces so they read better on the 3DS screen.
- Added a subtle board frame for better separation from the background.
- Made file/rank coordinates larger and added a drop shadow so square notation is finally readable.

# Changelog

## v1.2
- Completely redesigned Chess3DS UI around a charcoal/green online-chess visual language.
- New cream/green default board with in-board coordinates and modern move highlights.
- Replaced the old procedural pieces with a new original Staunton-style vector set.
- Reworked main menu, game HUD, setup, settings, statistics, puzzles, pause and about screens.
- Replaced difficulty levels 1–8 with a 400–2600 ELO selector.
- Uses Stockfish 11 `UCI_LimitStrength`/`UCI_Elo` from 1350 upward; weaker ratings use Skill Level plus shorter searches.
- Migrates existing v1.1 settings/saves/statistics from old level values to approximate ELO automatically.
- Stockfish initialization now waits until the player actually starts a CPU game.

## v1.1.1
- Old 3DS safe-boot: smaller main stack and Citro2D object pool.
- App state moved to heap with allocation failure handling.
- Stockfish implementation allocated only when CPU mode is selected.
- Stockfish worker stack reduced from 2 MiB to 1 MiB for short searches.
- Old 3DS Stockfish hash reduced to 1 MiB and 3DS release assertions disabled.
- Saved-game availability cached instead of hitting SD every menu frame.
- Smaller Citro2D text buffer.

## 1.0.1

- Hardened startup after an immediate crash was observed on physical Old 3DS hardware.
- Increased the libctru main stack from its small default to 1 MiB.
- Load Stockfish and NDSP audio on demand instead of before the first frame.
- Use a 2 MiB Stockfish worker stack and handle thread/allocation failures.
- Removed temporary helper threads used for hash clearing and result waiting.
- Added `/3ds/Chess3DS/last_stage.txt` crash-stage diagnostics.

## 1.0.0

- Initial full Chess3DS release.
- Complete legal move generator and game adjudication.
- Embedded Stockfish 11 with eight difficulty levels.
- CPU and local two-player modes with four clock presets.
- Touch and button controls, animations, sounds and four themes.
- Autosave, PGN export, statistics and five mate puzzles.
- Polish and English user interface.
