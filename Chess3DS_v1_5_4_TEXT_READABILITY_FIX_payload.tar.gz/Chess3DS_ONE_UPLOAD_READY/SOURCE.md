# Corresponding source code

The complete corresponding source for Chess3DS is published at:

https://github.com/mexo4/Chess3DS

Build artifacts produced by GitHub Actions correspond to the commit shown on
the workflow run page. The repository includes the complete Stockfish 11 source,
all Chess3DS modifications, the build scripts, and the exact toolchain workflow.

Chess3DS and its embedded Stockfish derivative are licensed under GNU GPL v3 or
later. See `LICENSE` and `THIRD_PARTY.md`.

## v1.5 visual source
The v1.5 chess-piece sprites are derived from the project owner-approved Concept A reference image supplied during development. No Chess.com image asset files are bundled.
