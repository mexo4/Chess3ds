#pragma once

#include <cstdint>
#include <memory>
#include <string>

namespace chess3ds::engine {

struct EngineResult {
    std::string bestMoveUci;
    int evaluationCp{0};
    int depth{0};
    std::uint64_t nodes{0};
};

class StockfishEngine {
public:
    StockfishEngine();
    ~StockfishEngine();

    StockfishEngine(const StockfishEngine&) = delete;
    StockfishEngine& operator=(const StockfishEngine&) = delete;

    bool initialize();
    void shutdown();
    bool isInitialized() const;

    // Rating is presented to the player as an approximate chess rating.
    // Stockfish 11's native UCI_Elo option is used where supported; lower
    // ratings are emulated with Skill Level and short searches.
    bool start(const std::string& fen, int elo, int thinkTimeMs);
    bool poll(EngineResult& result);
    bool isThinking() const;
    void stop();

    static int clampElo(int elo);
    static int skillForElo(int elo);
    static int defaultThinkTimeMsForElo(int elo);

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace chess3ds::engine
