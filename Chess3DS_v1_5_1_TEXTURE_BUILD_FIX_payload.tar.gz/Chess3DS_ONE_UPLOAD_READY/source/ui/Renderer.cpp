#include "ui/Renderer.hpp"
#include "pieces_t3x.h"

#include <algorithm>
#include <cmath>

namespace chess3ds::ui {
namespace {

constexpr float BoardX = 40.0f;
constexpr float BoardY = 0.0f;
constexpr float SquareSize = 30.0f;

std::uint32_t withAlpha(std::uint32_t color, std::uint8_t alpha) {
    return (color & 0x00FFFFFFu) | (static_cast<std::uint32_t>(alpha) << 24u);
}

float ease(float value) {
    value = std::clamp(value, 0.0f, 1.0f);
    return value * value * (3.0f - 2.0f * value);
}

std::uint32_t mixAlpha(std::uint32_t color, float factor) {
    const auto alpha = static_cast<std::uint8_t>(std::clamp(factor, 0.0f, 1.0f) * 255.0f);
    return withAlpha(color, alpha);
}

} // namespace

bool Renderer::initialize() {
    top_ = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    bottom_ = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    textBuffer_ = C2D_TextBufNew(2048);
    if (!top_ || !bottom_ || !textBuffer_) return false;

    // v1.5: use the raster piece set extracted from the approved Concept A
    // reference instead of approximating the silhouettes with primitives.
    pieceSheet_ = C2D_SpriteSheetLoadFromMem(pieces_t3x, pieces_t3x_size);
    if (pieceSheet_ && C2D_SpriteSheetCount(pieceSheet_) >= 12) {
        C2D_Image first = C2D_SpriteSheetGetImage(pieceSheet_, 0);
        C3D_TexSetFilter(first.tex, GPU_LINEAR, GPU_LINEAR);
    } else if (pieceSheet_) {
        C2D_SpriteSheetFree(pieceSheet_);
        pieceSheet_ = nullptr;
    }
    return true;
}

void Renderer::shutdown() {
    if (pieceSheet_) C2D_SpriteSheetFree(pieceSheet_);
    pieceSheet_ = nullptr;
    if (textBuffer_) C2D_TextBufDelete(textBuffer_);
    textBuffer_ = nullptr;
    top_ = nullptr;
    bottom_ = nullptr;
}

void Renderer::beginFrame() {
    C2D_TextBufClear(textBuffer_);
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
}

void Renderer::beginTop(std::uint32_t clearColor) {
    C2D_TargetClear(top_, clearColor);
    C2D_SceneBegin(top_);
}

void Renderer::beginBottom(std::uint32_t clearColor) {
    C2D_TargetClear(bottom_, clearColor);
    C2D_SceneBegin(bottom_);
}

void Renderer::endFrame() {
    C3D_FrameEnd(0);
}

void Renderer::text(const std::string& value, float x, float y, float scale,
                    std::uint32_t color, int flags, float wrapWidth) {
    C2D_Text parsed;
    C2D_TextParse(&parsed, textBuffer_, value.c_str());
    C2D_TextOptimize(&parsed);
    const std::uint32_t drawFlags = static_cast<std::uint32_t>(flags) | C2D_WithColor
        | (wrapWidth > 0.0f ? C2D_WordWrap : 0);
    if (wrapWidth > 0.0f)
        C2D_DrawText(&parsed, drawFlags, x, y, 0.8f, scale, scale, color, wrapWidth);
    else
        C2D_DrawText(&parsed, drawFlags, x, y, 0.8f, scale, scale, color);
}

void Renderer::panel(const Rect& rect, std::uint32_t color, float radius) {
    if (radius <= 0.0f) {
        C2D_DrawRectSolid(rect.x, rect.y, 0.2f, rect.w, rect.h, color);
        return;
    }
    const float r = std::min({radius, rect.w * 0.5f, rect.h * 0.5f});
    C2D_DrawRectSolid(rect.x + r, rect.y, 0.2f, rect.w - 2.0f * r, rect.h, color);
    C2D_DrawRectSolid(rect.x, rect.y + r, 0.2f, rect.w, rect.h - 2.0f * r, color);
    C2D_DrawCircleSolid(rect.x + r, rect.y + r, 0.2f, r, color);
    C2D_DrawCircleSolid(rect.x + rect.w - r, rect.y + r, 0.2f, r, color);
    C2D_DrawCircleSolid(rect.x + r, rect.y + rect.h - r, 0.2f, r, color);
    C2D_DrawCircleSolid(rect.x + rect.w - r, rect.y + rect.h - r, 0.2f, r, color);
}

void Renderer::button(const Rect& rect, const std::string& label, bool selected,
                      bool disabled, const Palette& colors, const std::string& hint) {
    const std::uint32_t fill = selected ? colors.accent : colors.panel;
    const std::uint32_t shadow = selected
        ? C2D_Color32(83, 123, 45, disabled ? 100 : 220)
        : C2D_Color32(22, 21, 20, disabled ? 80 : 190);

    panel({rect.x, rect.y + 3.0f, rect.w, rect.h}, shadow, 6.0f);
    panel(rect, disabled ? withAlpha(colors.panel, 145) : fill, 6.0f);

    const std::uint32_t textColor = disabled ? colors.muted : colors.text;
    text(label, rect.x + 12.0f, rect.y + 7.0f, 0.47f, textColor);
    if (!hint.empty())
        text(hint, rect.x + rect.w - 10.0f, rect.y + 8.0f, 0.40f,
             disabled ? colors.muted : (selected ? colors.text : colors.muted), C2D_AlignRight);
}

void Renderer::progressBar(const Rect& rect, float progress, std::uint32_t back,
                           std::uint32_t fill) {
    panel(rect, back, rect.h * 0.5f);
    progress = std::clamp(progress, 0.0f, 1.0f);
    if (progress > 0.0f)
        panel(Rect{rect.x, rect.y, rect.w * progress, rect.h}, fill, rect.h * 0.5f);
}

Palette Renderer::palette(platform::Theme theme) {
    // Default theme intentionally follows the visual language of modern
    // online chess clients: charcoal chrome, cream/green board, bright green
    // primary actions. All art is drawn locally and does not use third-party assets.
    switch (theme) {
        case platform::Theme::Midnight:
            return {C2D_Color32(30, 32, 34, 255), C2D_Color32(45, 48, 51, 255),
                    C2D_Color32(57, 61, 64, 255), C2D_Color32(242, 242, 242, 255),
                    C2D_Color32(164, 168, 171, 255), C2D_Color32(129, 182, 76, 255),
                    C2D_Color32(218, 79, 73, 255), C2D_Color32(222, 227, 230, 255),
                    C2D_Color32(111, 137, 150, 255), C2D_Color32(246, 246, 105, 170),
                    C2D_Color32(205, 210, 106, 170)};
        case platform::Theme::Forest:
            return {C2D_Color32(36, 35, 32, 255), C2D_Color32(49, 47, 43, 255),
                    C2D_Color32(60, 58, 53, 255), C2D_Color32(242, 242, 242, 255),
                    C2D_Color32(170, 168, 162, 255), C2D_Color32(129, 182, 76, 255),
                    C2D_Color32(218, 79, 73, 255), C2D_Color32(232, 235, 209, 255),
                    C2D_Color32(96, 133, 77, 255), C2D_Color32(246, 246, 105, 170),
                    C2D_Color32(205, 210, 106, 170)};
        case platform::Theme::Rosewood:
            return {C2D_Color32(38, 35, 32, 255), C2D_Color32(51, 47, 43, 255),
                    C2D_Color32(63, 58, 52, 255), C2D_Color32(244, 242, 238, 255),
                    C2D_Color32(173, 166, 158, 255), C2D_Color32(129, 182, 76, 255),
                    C2D_Color32(218, 79, 73, 255), C2D_Color32(240, 217, 181, 255),
                    C2D_Color32(181, 136, 99, 255), C2D_Color32(246, 246, 105, 170),
                    C2D_Color32(205, 210, 106, 170)};
        case platform::Theme::Classic:
        case platform::Theme::Count:
            // Concept A reference palette: near-black chrome, warm ivory light
            // squares, muted olive-green dark squares and a restrained lime accent.
            return {C2D_Color32(22, 23, 22, 255), C2D_Color32(31, 32, 30, 255),
                    C2D_Color32(41, 43, 39, 255), C2D_Color32(244, 241, 226, 255),
                    C2D_Color32(175, 173, 160, 255), C2D_Color32(137, 174, 76, 255),
                    C2D_Color32(190, 72, 65, 255), C2D_Color32(241, 233, 201, 255),
                    C2D_Color32(137, 165, 88, 255), C2D_Color32(238, 207, 45, 195),
                    C2D_Color32(218, 205, 67, 175)};
    }
    return palette(platform::Theme::Classic);
}

Rect Renderer::boardRect() { return {BoardX, BoardY, SquareSize * 8.0f, SquareSize * 8.0f}; }

Rect Renderer::squareRect(int square, bool flipped) {
    if (!chess::validSquare(square)) return {};
    const int file = chess::fileOf(square);
    const int rank = chess::rankOf(square);
    const int screenFile = flipped ? 7 - file : file;
    const int screenRank = flipped ? rank : 7 - rank;
    return {BoardX + screenFile * SquareSize, BoardY + screenRank * SquareSize,
            SquareSize, SquareSize};
}

int Renderer::squareFromPoint(float x, float y, bool flipped) {
    if (!boardRect().contains(x, y)) return chess::NoSquare;
    const int screenFile = static_cast<int>((x - BoardX) / SquareSize);
    const int screenRank = static_cast<int>((y - BoardY) / SquareSize);
    const int file = flipped ? 7 - screenFile : screenFile;
    const int rank = flipped ? screenRank : 7 - screenRank;
    return rank * 8 + file;
}

void Renderer::board(const chess::Position& position, const Palette& colors, bool flipped,
                     int cursorSquare, int selectedSquare, const std::vector<chess::Move>& legalMoves,
                     const chess::Move* lastMove, const MoveAnimation& animation,
                     bool showLegalMoves) {
    C2D_DrawRectSolid(0, 0, 0.0f, 320, 240, colors.background);
    boardAt(position, colors, flipped, cursorSquare, selectedSquare, legalMoves,
            lastMove, animation, showLegalMoves, BoardX, BoardY, SquareSize);
}

void Renderer::boardAt(const chess::Position& position, const Palette& colors, bool flipped,
                       int cursorSquare, int selectedSquare,
                       const std::vector<chess::Move>& legalMoves,
                       const chess::Move* lastMove, const MoveAnimation& animation,
                       bool showLegalMoves, float boardX, float boardY, float squareSize) {
    const auto rectFor = [&](int square) -> Rect {
        if (!chess::validSquare(square)) return {};
        const int file = chess::fileOf(square);
        const int rank = chess::rankOf(square);
        const int screenFile = flipped ? 7 - file : file;
        const int screenRank = flipped ? rank : 7 - rank;
        return {boardX + screenFile * squareSize, boardY + screenRank * squareSize,
                squareSize, squareSize};
    };

    panel({boardX - 2.0f, boardY - 2.0f, squareSize * 8.0f + 4.0f,
           squareSize * 8.0f + 4.0f}, colors.panelAlt, 4.0f);

    for (int square = 0; square < 64; ++square) {
        const Rect rect = rectFor(square);
        const bool light = ((chess::fileOf(square) + chess::rankOf(square)) & 1) != 0;
        C2D_DrawRectSolid(rect.x, rect.y, 0.1f, rect.w, rect.h,
                          light ? colors.lightSquare : colors.darkSquare);
    }

    if (lastMove) {
        for (int square : {static_cast<int>(lastMove->from), static_cast<int>(lastMove->to)}) {
            const Rect rect = rectFor(square);
            C2D_DrawRectSolid(rect.x, rect.y, 0.2f, rect.w, rect.h, colors.lastMove);
        }
    }

    if (chess::validSquare(selectedSquare)) {
        const Rect rect = rectFor(selectedSquare);
        C2D_DrawRectSolid(rect.x, rect.y, 0.3f, rect.w, rect.h, colors.selected);
    }

    const int checkedKing = position.inCheck(position.sideToMove())
        ? position.kingSquare(position.sideToMove()) : chess::NoSquare;
    if (checkedKing != chess::NoSquare) {
        const Rect rect = rectFor(checkedKing);
        C2D_DrawCircleSolid(rect.x + rect.w * 0.5f, rect.y + rect.h * 0.5f, 0.35f,
                            rect.w * 0.43f, withAlpha(colors.danger, 180));
    }

    if (showLegalMoves && chess::validSquare(selectedSquare)) {
        for (const chess::Move& move : legalMoves) {
            const Rect rect = rectFor(move.to);
            if (move.isCapture()) {
                const std::uint32_t dot = mixAlpha(C2D_Color32(28, 28, 28, 255), 0.28f);
                C2D_DrawCircleSolid(rect.x + rect.w * 0.5f, rect.y + rect.h * 0.5f,
                                    0.4f, rect.w * 0.45f, dot);
                C2D_DrawCircleSolid(rect.x + rect.w * 0.5f, rect.y + rect.h * 0.5f,
                                    0.41f, rect.w * 0.32f,
                                    ((chess::fileOf(move.to) + chess::rankOf(move.to)) & 1)
                                        ? colors.lightSquare : colors.darkSquare);
            } else {
                C2D_DrawCircleSolid(rect.x + rect.w * 0.5f, rect.y + rect.h * 0.5f,
                                    0.4f, rect.w * 0.15f,
                                    mixAlpha(C2D_Color32(35, 35, 35, 255), 0.34f));
            }
        }
    }

    for (int square = 0; square < 64; ++square) {
        const chess::Piece value = position.pieceAt(square);
        if (!value) continue;
        if (animation.active && square == animation.move.to) continue;
        const Rect rect = rectFor(square);
        piece(value, rect.x + 1.0f, rect.y + 1.0f, rect.w - 2.0f);
    }

    if (animation.active) {
        const Rect from = rectFor(animation.move.from);
        const Rect to = rectFor(animation.move.to);
        const float t = ease(animation.progress);
        piece(animation.piece, from.x + 1.0f + (to.x - from.x) * t,
              from.y + 1.0f + (to.y - from.y) * t, squareSize - 2.0f);
    }

    auto drawCoord = [&](const std::string& value, float x, float y, float scale,
                         std::uint32_t color, bool alignRight = false, bool center = false) {
        const int flags = center ? C2D_AlignCenter : (alignRight ? C2D_AlignRight : 0);
        const std::uint32_t shadow = withAlpha(C2D_Color32(10, 10, 10, 255), 205);
        text(value, x + 0.55f, y + 0.55f, scale, shadow, flags);
        text(value, x, y, scale, color, flags);
    };

    // Concept A places ranks to the left and files below the board instead of
    // covering the pieces. The board is positioned with enough margin for them.
    const float coordScale = std::max(0.22f, squareSize / 105.0f);
    const std::uint32_t coordColor = C2D_Color32(183, 205, 108, 255);
    for (int i = 0; i < 8; ++i) {
        const int actualFile = flipped ? 7 - i : i;
        drawCoord(std::string(1, static_cast<char>('a' + actualFile)),
                  boardX + (i + 0.5f) * squareSize,
                  boardY + 8.0f * squareSize + 0.3f,
                  coordScale, coordColor, false, true);

        const int actualRank = flipped ? i : 7 - i;
        drawCoord(std::string(1, static_cast<char>('1' + actualRank)),
                  boardX - 2.0f,
                  boardY + i * squareSize + squareSize * 0.28f,
                  coordScale, coordColor, true, false);
    }

    if (chess::validSquare(cursorSquare)) {
        const Rect rect = rectFor(cursorSquare);
        const std::uint32_t cursor = withAlpha(C2D_Color32(255, 255, 255, 255), 225);
        const float line = std::max(1.2f, squareSize * 0.05f);
        C2D_DrawRectSolid(rect.x + 0.5f, rect.y + 0.5f, 0.85f, rect.w - 1.0f, line, cursor);
        C2D_DrawRectSolid(rect.x + 0.5f, rect.y + rect.h - line - 0.5f, 0.85f,
                          rect.w - 1.0f, line, cursor);
        C2D_DrawRectSolid(rect.x + 0.5f, rect.y + 0.5f, 0.85f, line, rect.h - 1.0f, cursor);
        C2D_DrawRectSolid(rect.x + rect.w - line - 0.5f, rect.y + 0.5f, 0.85f,
                          line, rect.h - 1.0f, cursor);
    }
}

void Renderer::outlinedEllipse(float x, float y, float w, float h,
                               std::uint32_t outline, std::uint32_t fill, float border) {
    C2D_DrawEllipseSolid(x, y, 0.61f, w, h, outline);
    C2D_DrawEllipseSolid(x + border, y + border, 0.62f,
                         std::max(0.0f, w - border * 2.0f),
                         std::max(0.0f, h - border * 2.0f), fill);
}

void Renderer::outlinedRect(float x, float y, float w, float h,
                            std::uint32_t outline, std::uint32_t fill, float border) {
    C2D_DrawRectSolid(x, y, 0.61f, w, h, outline);
    C2D_DrawRectSolid(x + border, y + border, 0.62f,
                      std::max(0.0f, w - border * 2.0f),
                      std::max(0.0f, h - border * 2.0f), fill);
}

void Renderer::piece(chess::Piece value, float x, float y, float size, std::uint8_t alpha) {
    if (!value) return;

    if (pieceSheet_ && alpha == 255) {
        int localIndex = -1;
        switch (value.type) {
            case chess::PieceType::King:   localIndex = 0; break;
            case chess::PieceType::Queen:  localIndex = 1; break;
            case chess::PieceType::Rook:   localIndex = 2; break;
            case chess::PieceType::Bishop: localIndex = 3; break;
            case chess::PieceType::Knight: localIndex = 4; break;
            case chess::PieceType::Pawn:   localIndex = 5; break;
            case chess::PieceType::None:   break;
        }
        if (localIndex >= 0) {
            const int index = localIndex + (value.color == chess::Color::Black ? 6 : 0);
            const C2D_Image image = C2D_SpriteSheetGetImage(pieceSheet_, static_cast<size_t>(index));
            const float scale = size / static_cast<float>(image.subtex->width);
            C2D_DrawImageAt(image, x, y, 0.64f, nullptr, scale, scale);
            return;
        }
    }

    const float s = size / 32.0f;
    auto X = [&](float vx) { return x + vx * s; };
    auto Y = [&](float vy) { return y + vy * s; };

    const bool white = value.color == chess::Color::White;
    const std::uint32_t outline = withAlpha(white
        ? C2D_Color32(102, 99, 92, 255)
        : C2D_Color32(22, 22, 22, 255), alpha);
    const std::uint32_t fill = withAlpha(white
        ? C2D_Color32(250, 249, 244, 255)
        : C2D_Color32(62, 62, 61, 255), alpha);
    const std::uint32_t highlight = withAlpha(white
        ? C2D_Color32(255, 255, 255, 255)
        : C2D_Color32(94, 94, 92, 255), alpha);
    const std::uint32_t detail = withAlpha(white
        ? C2D_Color32(150, 146, 137, 255)
        : C2D_Color32(18, 18, 18, 255), alpha);
    const std::uint32_t shadow = withAlpha(C2D_Color32(0, 0, 0, 255),
                                           static_cast<std::uint8_t>(alpha * 0.16f));
    const float b = std::max(0.75f, 0.95f * s);

    C2D_DrawEllipseSolid(X(5.5f), Y(27.1f), 0.54f, 21.0f * s, 2.4f * s, shadow);

    auto base = [&]() {
        outlinedEllipse(X(5.2f), Y(24.5f), 21.0f * s, 3.8f * s, outline, fill, b);
        outlinedRect(X(7.5f), Y(22.1f), 16.4f * s, 3.3f * s, outline, fill, b);
        outlinedRect(X(10.2f), Y(20.4f), 11.0f * s, 2.2f * s, outline, fill, b * 0.9f);
    };

    auto stem = [&](float left, float right, float topY, float topWidth) {
        C2D_DrawTriangle(X(left), Y(20.8f), outline,
                         X(right), Y(20.8f), outline,
                         X(16.0f), Y(topY), outline, 0.60f);
        C2D_DrawTriangle(X(left + 1.2f), Y(20.0f), fill,
                         X(right - 1.2f), Y(20.0f), fill,
                         X(16.0f), Y(topY + 1.2f), fill, 0.62f);
        outlinedEllipse(X(16.0f - topWidth * 0.5f), Y(topY - 0.2f),
                        topWidth * s, 2.8f * s, outline, fill, b * 0.85f);
        C2D_DrawEllipseSolid(X(16.0f - topWidth * 0.5f + 1.0f), Y(topY + 0.2f), 0.66f,
                             std::max(0.0f, topWidth * s - 2.0f * s), 0.9f * s, highlight);
    };

    auto smallTopShine = [&](float x0, float y0, float w, float h) {
        C2D_DrawEllipseSolid(X(x0), Y(y0), 0.68f, w * s, h * s, highlight);
    };

    switch (value.type) {
        case chess::PieceType::Pawn: {
            base();
            stem(10.5f, 21.5f, 12.8f, 8.8f);
            outlinedEllipse(X(11.0f), Y(4.0f), 10.0f * s, 10.0f * s, outline, fill, b);
            smallTopShine(12.5f, 5.4f, 4.0f, 1.5f);
            break;
        }

        case chess::PieceType::Rook: {
            base();
            outlinedRect(X(10.0f), Y(9.4f), 12.0f * s, 11.8f * s, outline, fill, b);
            C2D_DrawRectSolid(X(11.2f), Y(10.4f), 0.66f, 9.6f * s, 1.0f * s, highlight);
            outlinedRect(X(8.1f), Y(6.4f), 15.8f * s, 4.2f * s, outline, fill, b);
            for (float cx : {8.1f, 13.0f, 17.9f, 22.8f}) {
                outlinedRect(X(cx), Y(3.4f), 3.0f * s, 4.0f * s, outline, fill, b * 0.78f);
            }
            C2D_DrawLine(X(12.0f), Y(12.2f), detail, X(12.0f), Y(20.1f), detail, 0.9f * s, 0.73f);
            C2D_DrawLine(X(16.0f), Y(12.2f), detail, X(16.0f), Y(20.1f), detail, 0.9f * s, 0.73f);
            C2D_DrawLine(X(20.0f), Y(12.2f), detail, X(20.0f), Y(20.1f), detail, 0.9f * s, 0.73f);
            break;
        }

        case chess::PieceType::Knight: {
            base();
            C2D_DrawTriangle(X(8.7f), Y(21.2f), outline,
                             X(22.2f), Y(21.2f), outline,
                             X(13.0f), Y(8.2f), outline, 0.60f);
            C2D_DrawTriangle(X(10.1f), Y(20.1f), fill,
                             X(20.5f), Y(20.1f), fill,
                             X(13.6f), Y(9.8f), fill, 0.62f);
            outlinedEllipse(X(10.2f), Y(6.0f), 10.8f * s, 8.4f * s, outline, fill, b);
            C2D_DrawTriangle(X(13.6f), Y(7.6f), outline,
                             X(23.7f), Y(11.3f), outline,
                             X(13.1f), Y(15.6f), outline, 0.64f);
            C2D_DrawTriangle(X(14.4f), Y(8.8f), fill,
                             X(21.5f), Y(11.2f), fill,
                             X(14.1f), Y(14.1f), fill, 0.66f);
            C2D_DrawTriangle(X(11.8f), Y(6.9f), outline,
                             X(11.0f), Y(2.5f), outline,
                             X(16.2f), Y(6.0f), outline, 0.67f);
            C2D_DrawTriangle(X(12.7f), Y(6.2f), fill,
                             X(12.4f), Y(4.3f), fill,
                             X(14.8f), Y(5.8f), fill, 0.69f);
            C2D_DrawLine(X(10.8f), Y(8.5f), detail, X(9.1f), Y(18.0f), detail, 1.05f * s, 0.72f);
            C2D_DrawCircleSolid(X(16.8f), Y(8.9f), 0.74f, 0.9f * s, detail);
            break;
        }

        case chess::PieceType::Bishop: {
            base();
            stem(10.2f, 21.8f, 12.5f, 8.7f);
            outlinedEllipse(X(10.9f), Y(3.4f), 10.2f * s, 12.2f * s, outline, fill, b);
            C2D_DrawLine(X(13.0f), Y(12.8f), detail,
                         X(18.6f), Y(5.2f), detail, 1.35f * s, 0.74f);
            smallTopShine(12.8f, 5.1f, 4.0f, 1.3f);
            break;
        }

        case chess::PieceType::Queen: {
            base();
            stem(9.6f, 22.4f, 13.2f, 11.4f);
            C2D_DrawTriangle(X(9.0f), Y(13.8f), outline,
                             X(23.0f), Y(13.8f), outline,
                             X(10.0f), Y(7.0f), outline, 0.61f);
            C2D_DrawTriangle(X(10.4f), Y(12.8f), fill,
                             X(21.6f), Y(12.8f), fill,
                             X(11.1f), Y(8.2f), fill, 0.63f);
            for (float cx : {9.2f, 12.6f, 16.0f, 19.4f, 22.8f}) {
                const float cy = (cx == 16.0f) ? 2.6f : ((cx == 12.6f || cx == 19.4f) ? 3.8f : 5.0f);
                outlinedEllipse(X(cx - 1.4f), Y(cy), 2.8f * s, 2.8f * s, outline, fill, b * 0.68f);
            }
            C2D_DrawLine(X(10.8f), Y(11.9f), highlight,
                         X(20.9f), Y(11.9f), highlight, 0.9f * s, 0.70f);
            break;
        }

        case chess::PieceType::King: {
            base();
            stem(10.0f, 22.0f, 13.0f, 9.8f);
            outlinedEllipse(X(11.2f), Y(8.1f), 9.6f * s, 6.8f * s, outline, fill, b);
            outlinedRect(X(14.2f), Y(0.8f), 3.2f * s, 8.6f * s, outline, fill, b * 0.56f);
            outlinedRect(X(11.2f), Y(3.6f), 9.2f * s, 3.0f * s, outline, fill, b * 0.56f);
            C2D_DrawRectSolid(X(15.0f), Y(1.9f), 0.68f, 1.6f * s, 5.2f * s, highlight);
            break;
        }

        case chess::PieceType::None:
            break;
    }
}

void Renderer::logo(float centerX, float centerY, float size, const Palette& colors) {
    const Rect tile{centerX - size * 0.5f, centerY - size * 0.5f, size, size};
    panel({tile.x, tile.y + 4.0f, tile.w, tile.h}, C2D_Color32(72, 108, 39, 210), size * 0.16f);
    panel(tile, colors.accent, size * 0.16f);
    panel({tile.x + size * 0.12f, tile.y + size * 0.12f, size * 0.76f, size * 0.76f},
          C2D_Color32(244, 244, 240, 120), size * 0.10f);
    chess::Piece knight{chess::PieceType::Knight, chess::Color::White};
    piece(knight, tile.x + size * 0.11f, tile.y + size * 0.10f, size * 0.78f);
}

} // namespace chess3ds::ui
