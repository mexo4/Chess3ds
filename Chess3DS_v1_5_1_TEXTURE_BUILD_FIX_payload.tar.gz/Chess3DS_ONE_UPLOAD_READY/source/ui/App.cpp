#include "ui/App.hpp"
#include "platform/Diagnostics.hpp"

#include <algorithm>
#include <array>
#include <cstdio>
#include <cstdlib>
#include <sstream>

namespace chess3ds::ui {
namespace {

Rect gridButtonRect(int index) {
    const int column = index & 1;
    const int row = index / 2;
    return {10.0f + column * 155.0f, 12.0f + row * 55.0f, 145.0f, 45.0f};
}

Rect listButtonRect(int index, float height = 32.0f, float startY = 10.0f) {
    return {12.0f, startY + index * (height + 4.0f), 296.0f, height};
}

Rect gameTouchButtonRect(int index) {
    return {4.0f + index * 63.0f, 184.0f, 60.0f, 48.0f};
}

bool isDraw(chess::GameResult result) {
    return result == chess::GameResult::DrawStalemate
        || result == chess::GameResult::DrawRepetition
        || result == chess::GameResult::DrawFiftyMove
        || result == chess::GameResult::DrawInsufficientMaterial;
}

chess::Color winner(chess::GameResult result) {
    switch (result) {
        case chess::GameResult::WhiteCheckmate:
        case chess::GameResult::BlackResigned:
        case chess::GameResult::BlackTimeout: return chess::Color::White;
        default: return chess::Color::Black;
    }
}

std::string basenameOf(const std::string& path) {
    const std::size_t separator = path.find_last_of("/\\");
    return separator == std::string::npos ? path : path.substr(separator + 1);
}

} // namespace

int App::run() {
    if (!renderer_.initialize()) return 1;
    platform::writeRuntimeStage("renderer");
    storage_.initialize();
    storage_.loadSettings(settings_);
    storage_.loadStatistics(statistics_);
    hasSavedGame_ = storage_.hasSavedGame();
    sound_.setEnabled(settings_.sound);
    // Sound and Stockfish are deliberately initialized only when first used.
    // Both may create platform services/threads, so the main menu must render
    // successfully before either is touched.
    platform::writeRuntimeStage("menu");

    previousTickMs_ = osGetTime();
    while (running_ && aptMainLoop()) {
        const std::uint64_t now = osGetTime();
        const float delta = static_cast<float>(std::min<std::uint64_t>(100, now - previousTickMs_));
        previousTickMs_ = now;

        hidScanInput();
        touchPosition touch{};
        hidTouchRead(&touch);
        const std::uint32_t down = hidKeysDown();
        const std::uint32_t held = hidKeysHeld();

        handleInput(down, held, touch, now);
        update(delta, now);
        render(now);
    }

    if (screen_ == Screen::Game && game_.result() == chess::GameResult::Ongoing && !puzzleMode_)
        saveCurrentGame();
    storage_.saveSettings(settings_);
    storage_.saveStatistics(statistics_);
    engine_.shutdown();
    sound_.shutdown();
    renderer_.shutdown();
    return 0;
}

std::vector<App::MainAction> App::mainActions() const {
    std::vector<MainAction> actions;
    if (hasSavedGame_) actions.push_back(MainAction::Continue);
    actions.insert(actions.end(), {MainAction::Cpu, MainAction::Local, MainAction::Puzzles,
                                   MainAction::Settings, MainAction::Statistics,
                                   MainAction::About, MainAction::Exit});
    return actions;
}

void App::handleInput(std::uint32_t down, std::uint32_t held, const touchPosition& touch,
                      std::uint64_t) {
    switch (screen_) {
        case Screen::MainMenu: handleMainMenu(down, touch); break;
        case Screen::Setup: handleSetup(down, touch); break;
        case Screen::Game: handleGame(down, held, touch); break;
        case Screen::Pause: handlePause(down, touch); break;
        case Screen::Settings: handleSettings(down, touch); break;
        case Screen::Puzzles: handlePuzzles(down, touch); break;
        case Screen::Statistics:
        case Screen::About:
            if (down & (KEY_A | KEY_B | KEY_START)) returnToMainMenu();
            break;
    }
}

void App::handleMainMenu(std::uint32_t down, const touchPosition& touch) {
    const auto actions = mainActions();
    if (actions.empty()) return;
    menuIndex_ = std::clamp(menuIndex_, 0, static_cast<int>(actions.size()) - 1);

    if (down & KEY_LEFT) menuIndex_ = std::max(0, menuIndex_ - 1);
    if (down & KEY_RIGHT) menuIndex_ = std::min(static_cast<int>(actions.size()) - 1, menuIndex_ + 1);
    if (down & KEY_UP) menuIndex_ = std::max(0, menuIndex_ - 2);
    if (down & KEY_DOWN) menuIndex_ = std::min(static_cast<int>(actions.size()) - 1, menuIndex_ + 2);

    bool activate = (down & KEY_A) != 0;
    if (down & KEY_TOUCH) {
        for (int i = 0; i < static_cast<int>(actions.size()); ++i) {
            if (gridButtonRect(i).contains(touch.px, touch.py)) {
                menuIndex_ = i;
                activate = true;
                break;
            }
        }
    }
    if (down & KEY_START) running_ = false;
    if (!activate) return;

    switch (actions[menuIndex_]) {
        case MainAction::Continue: resumeSavedGame(); break;
        case MainAction::Cpu:
            // Keep the setup screen instant; initialize Stockfish only when
            // the player actually starts the game.
            setupMode_ = platform::GameMode::Cpu;
            setupIndex_ = 0;
            screen_ = Screen::Setup;
            break;
        case MainAction::Local:
            setupMode_ = platform::GameMode::Local;
            setupIndex_ = 0;
            screen_ = Screen::Setup;
            break;
        case MainAction::Puzzles:
            puzzleIndex_ = 0;
            screen_ = Screen::Puzzles;
            break;
        case MainAction::Settings:
            settingsReturnToGame_ = false;
            settingsIndex_ = 0;
            screen_ = Screen::Settings;
            break;
        case MainAction::Statistics: screen_ = Screen::Statistics; break;
        case MainAction::About: screen_ = Screen::About; break;
        case MainAction::Exit: running_ = false; break;
    }
}

void App::handleSetup(std::uint32_t down, const touchPosition& touch) {
    const int count = setupMode_ == platform::GameMode::Cpu ? 5 : 3;
    if (down & KEY_UP) setupIndex_ = (setupIndex_ + count - 1) % count;
    if (down & KEY_DOWN) setupIndex_ = (setupIndex_ + 1) % count;
    bool activate = (down & KEY_A) != 0;
    int direction = (down & (KEY_LEFT | KEY_L)) ? -1
        : ((down & (KEY_RIGHT | KEY_R)) ? 1 : 0);
    if (down & KEY_TOUCH) {
        for (int i = 0; i < count; ++i) {
            if (listButtonRect(i, 36.0f, 18.0f).contains(touch.px, touch.py)) {
                setupIndex_ = i;
                activate = true;
                break;
            }
        }
    }
    if (down & KEY_B) {
        screen_ = Screen::MainMenu;
        menuIndex_ = 0;
        return;
    }

    if (setupMode_ == platform::GameMode::Cpu) {
        if (setupIndex_ == 0 && (direction || activate)) setupSide_ = (setupSide_ + (direction < 0 ? 2 : 1)) % 3;
        if (setupIndex_ == 1 && (direction || activate))
            setupTimeControl_ = static_cast<platform::TimeControl>((static_cast<int>(setupTimeControl_) + (direction < 0 ? 3 : 1)) % 4);
        if (setupIndex_ == 2 && (direction || activate)) {
            const int step = direction < 0 ? -100 : 100;
            settings_.engineElo = engine::StockfishEngine::clampElo(settings_.engineElo + step);
        }
        if (setupIndex_ == 3 && activate) startNewGame();
        if (setupIndex_ == 4 && activate) screen_ = Screen::MainMenu;
    } else {
        if (setupIndex_ == 0 && (direction || activate))
            setupTimeControl_ = static_cast<platform::TimeControl>((static_cast<int>(setupTimeControl_) + (direction < 0 ? 3 : 1)) % 4);
        if (setupIndex_ == 1 && activate) startNewGame();
        if (setupIndex_ == 2 && activate) screen_ = Screen::MainMenu;
    }
    storage_.saveSettings(settings_);
}

void App::handleSettings(std::uint32_t down, const touchPosition& touch) {
    constexpr int Count = 8;
    if (down & KEY_UP) settingsIndex_ = (settingsIndex_ + Count - 1) % Count;
    if (down & KEY_DOWN) settingsIndex_ = (settingsIndex_ + 1) % Count;
    int direction = (down & (KEY_LEFT | KEY_L)) ? -1
        : ((down & (KEY_RIGHT | KEY_R)) ? 1 : 0);
    bool activate = (down & KEY_A) != 0;
    if (down & KEY_TOUCH) {
        for (int i = 0; i < Count; ++i) {
            if (listButtonRect(i, 24.0f, 4.0f).contains(touch.px, touch.py)) {
                settingsIndex_ = i;
                activate = true;
                break;
            }
        }
    }
    if (down & KEY_B) {
        storage_.saveSettings(settings_);
        if (settingsReturnToGame_) {
            settingsReturnToGame_ = false;
            screen_ = Screen::Game;
            startEngineIfNeeded();
        } else {
            returnToMainMenu();
        }
        return;
    }
    if (!direction && !activate) return;
    const int step = direction < 0 ? -1 : 1;
    switch (settingsIndex_) {
        case 0:
            settings_.engineElo = engine::StockfishEngine::clampElo(settings_.engineElo + step * 100);
            break;
        case 1: {
            const int count = static_cast<int>(platform::Theme::Count);
            settings_.theme = static_cast<platform::Theme>((static_cast<int>(settings_.theme) + (step < 0 ? count - 1 : 1)) % count);
            break;
        }
        case 2: settings_.language = settings_.language == platform::Language::Polish
                    ? platform::Language::English : platform::Language::Polish; break;
        case 3: settings_.sound = !settings_.sound; sound_.setEnabled(settings_.sound); break;
        case 4: settings_.showLegalMoves = !settings_.showLegalMoves; break;
        case 5: settings_.animations = !settings_.animations; break;
        case 6: settings_.autoFlipLocal = !settings_.autoFlipLocal; break;
        case 7:
            storage_.saveSettings(settings_);
            if (settingsReturnToGame_) {
                settingsReturnToGame_ = false;
                screen_ = Screen::Game;
                startEngineIfNeeded();
            } else {
                returnToMainMenu();
            }
            return;
    }
    storage_.saveSettings(settings_);
}

void App::handlePuzzles(std::uint32_t down, const touchPosition& touch) {
    const int count = static_cast<int>(puzzles().size()) + 1;
    if (down & KEY_UP) puzzleIndex_ = (puzzleIndex_ + count - 1) % count;
    if (down & KEY_DOWN) puzzleIndex_ = (puzzleIndex_ + 1) % count;
    bool activate = (down & KEY_A) != 0;
    if (down & KEY_TOUCH) {
        for (int i = 0; i < count; ++i) {
            if (listButtonRect(i, 28.0f, 8.0f).contains(touch.px, touch.py)) {
                puzzleIndex_ = i;
                activate = true;
                break;
            }
        }
    }
    if (down & KEY_B) returnToMainMenu();
    else if (activate) {
        if (puzzleIndex_ == static_cast<int>(puzzles().size())) returnToMainMenu();
        else startPuzzle(puzzleIndex_);
    }
}

void App::handleGame(std::uint32_t down, std::uint32_t, const touchPosition& touch) {
    if (puzzleSolved_ || game_.result() != chess::GameResult::Ongoing) {
        if (down & KEY_A) {
            if (puzzleMode_) startPuzzle((activePuzzle_ + 1) % static_cast<int>(puzzles().size()));
            else startNewGame();
        }
        if (down & (KEY_B | KEY_START)) returnToMainMenu();
        return;
    }

    if (!promotionChoices_.empty()) {
        if (down & KEY_LEFT) promotionIndex_ = (promotionIndex_ + 3) % 4;
        if (down & KEY_RIGHT) promotionIndex_ = (promotionIndex_ + 1) % 4;
        if (down & KEY_A) choosePromotion(promotionIndex_);
        if (down & KEY_B) promotionChoices_.clear();
        if (down & KEY_TOUCH) {
            for (int i = 0; i < static_cast<int>(promotionChoices_.size()); ++i) {
                const Rect rect{55.0f + i * 53.0f, 102.0f, 46.0f, 50.0f};
                if (rect.contains(touch.px, touch.py)) choosePromotion(i);
            }
        }
        return;
    }

    if (down & KEY_START) {
        engine_.stop();
        screen_ = Screen::Pause;
        menuIndex_ = 0;
        selectedSquare_ = chess::NoSquare;
        selectedMoves_.clear();
        return;
    }
    if (down & KEY_X) flipped_ = !flipped_;
    if (down & KEY_Y) undoMove();
    if (down & KEY_B) {
        if (selectedSquare_ != chess::NoSquare) {
            selectedSquare_ = chess::NoSquare;
            selectedMoves_.clear();
        } else {
            engine_.stop();
            screen_ = Screen::Pause;
            menuIndex_ = 0;
        }
        return;
    }

    int file = chess::fileOf(cursorSquare_);
    int rank = chess::rankOf(cursorSquare_);
    if (down & KEY_LEFT) file += flipped_ ? 1 : -1;
    if (down & KEY_RIGHT) file += flipped_ ? -1 : 1;
    if (down & KEY_UP) rank += flipped_ ? -1 : 1;
    if (down & KEY_DOWN) rank += flipped_ ? 1 : -1;
    file = std::clamp(file, 0, 7);
    rank = std::clamp(rank, 0, 7);
    cursorSquare_ = rank * 8 + file;

    if ((down & KEY_A) && isHumanTurn())
        selectedSquare_ == chess::NoSquare ? selectSquare(cursorSquare_) : attemptMoveTo(cursorSquare_);
    if (down & KEY_TOUCH) {
        for (int i = 0; i < 5; ++i) {
            if (!gameTouchButtonRect(i).contains(touch.px, touch.py)) continue;
            switch (i) {
                case 0: // Menu / pause
                    engine_.stop();
                    screen_ = Screen::Pause;
                    menuIndex_ = 0;
                    selectedSquare_ = chess::NoSquare;
                    selectedMoves_.clear();
                    break;
                case 1: // Undo
                    undoMove();
                    break;
                case 2: // Hint = show legal moves for the cursor piece
                    settings_.showLegalMoves = true;
                    storage_.saveSettings(settings_);
                    if (isHumanTurn() && selectedSquare_ == chess::NoSquare)
                        selectSquare(cursorSquare_);
                    showToast(tr("Podświetlono legalne ruchy", "Legal moves highlighted"));
                    break;
                case 3: // In-game settings
                    engine_.stop();
                    settingsReturnToGame_ = true;
                    screen_ = Screen::Settings;
                    settingsIndex_ = 0;
                    break;
                case 4: // Resign
                    game_.resign(gameMode_ == platform::GameMode::Cpu
                        ? playerColor_ : game_.position().sideToMove());
                    finalizeResult();
                    break;
            }
            break;
        }
    }
}

void App::handlePause(std::uint32_t down, const touchPosition& touch) {
    constexpr int Count = 4;
    if (down & KEY_UP) menuIndex_ = (menuIndex_ + Count - 1) % Count;
    if (down & KEY_DOWN) menuIndex_ = (menuIndex_ + 1) % Count;
    bool activate = (down & KEY_A) != 0;
    if (down & KEY_TOUCH) {
        for (int i = 0; i < Count; ++i) {
            if (listButtonRect(i, 38.0f, 24.0f).contains(touch.px, touch.py)) {
                menuIndex_ = i;
                activate = true;
                break;
            }
        }
    }
    if (down & (KEY_B | KEY_START)) {
        screen_ = Screen::Game;
        startEngineIfNeeded();
        return;
    }
    if (!activate) return;
    switch (menuIndex_) {
        case 0: screen_ = Screen::Game; startEngineIfNeeded(); break;
        case 1: saveCurrentGame(); returnToMainMenu(); break;
        case 2:
            game_.resign(gameMode_ == platform::GameMode::Cpu ? playerColor_ : game_.position().sideToMove());
            screen_ = Screen::Game;
            finalizeResult();
            break;
        case 3: exportCurrentPgn(); break;
    }
}

void App::startNewGame() {
    engine_.stop();
    if (setupMode_ == platform::GameMode::Cpu && !ensureEngineAvailable()) {
        screen_ = Screen::MainMenu;
        showToast(tr("Stockfish nie uruchomił się", "Stockfish is unavailable"));
        return;
    }
    game_.reset();
    gameMode_ = setupMode_;
    timeControl_ = setupTimeControl_;
    gameEngineElo_ = settings_.engineElo;
    if (gameMode_ == platform::GameMode::Cpu) {
        if (setupSide_ == 2) playerColor_ = (osGetTime() & 1u) ? chess::Color::White : chess::Color::Black;
        else playerColor_ = setupSide_ == 0 ? chess::Color::White : chess::Color::Black;
    } else playerColor_ = chess::Color::White;

    const platform::ClockPreset clock = platform::clockPreset(timeControl_);
    whiteTimeMs_ = blackTimeMs_ = clock.initialMs;
    incrementMs_ = clock.incrementMs;
    flipped_ = gameMode_ == platform::GameMode::Cpu && playerColor_ == chess::Color::Black;
    cursorSquare_ = flipped_ ? chess::parseSquare("e7") : chess::parseSquare("e2");
    selectedSquare_ = chess::NoSquare;
    selectedMoves_.clear();
    lastMove_.reset();
    animation_ = {};
    pendingAutoFlip_ = false;
    pendingEngineResult_.reset();
    resultFinalized_ = false;
    puzzleMode_ = false;
    puzzleSolved_ = false;
    lastEvaluationCp_ = 0;
    lastEngineDepth_ = 0;
    screen_ = Screen::Game;
    saveCurrentGame();
    startEngineIfNeeded();
}

void App::resumeSavedGame() {
    platform::SavedGame saved;
    std::string error;
    if (!storage_.loadGame(saved) || !game_.restore(saved.initialFen, saved.moves, &error)) {
        storage_.clearSavedGame();
        hasSavedGame_ = false;
        showToast(tr("Nie można odczytać zapisu", "Could not load save"));
        return;
    }
    if (saved.mode == platform::GameMode::Cpu && !ensureEngineAvailable()) {
        showToast(tr("Stockfish nie uruchomił się", "Stockfish is unavailable"));
        return;
    }
    gameMode_ = saved.mode;
    timeControl_ = saved.timeControl;
    playerColor_ = saved.playerColor;
    gameEngineElo_ = saved.engineElo;
    whiteTimeMs_ = saved.whiteTimeMs;
    blackTimeMs_ = saved.blackTimeMs;
    incrementMs_ = saved.incrementMs;
    flipped_ = gameMode_ == platform::GameMode::Cpu
        ? playerColor_ == chess::Color::Black
        : (settings_.autoFlipLocal && game_.position().sideToMove() == chess::Color::Black);
    cursorSquare_ = flipped_ ? chess::parseSquare("e7") : chess::parseSquare("e2");
    selectedSquare_ = chess::NoSquare;
    selectedMoves_.clear();
    lastMove_ = game_.history().empty() ? std::optional<chess::Move>{}
                                        : std::optional<chess::Move>{game_.history().back().move};
    animation_ = {};
    pendingAutoFlip_ = false;
    pendingEngineResult_.reset();
    resultFinalized_ = false;
    puzzleMode_ = false;
    puzzleSolved_ = false;
    screen_ = Screen::Game;
    startEngineIfNeeded();
}

void App::startPuzzle(int index) {
    engine_.stop();
    activePuzzle_ = std::clamp(index, 0, static_cast<int>(puzzles().size()) - 1);
    chess::Position position;
    std::string error;
    if (!chess::Position::fromFen(puzzles()[activePuzzle_].fen, position, &error)) {
        showToast("Puzzle error");
        return;
    }
    game_.reset(position, puzzles()[activePuzzle_].fen);
    puzzleMode_ = true;
    puzzleSolved_ = false;
    puzzleStep_ = 0;
    gameMode_ = platform::GameMode::Local;
    timeControl_ = platform::TimeControl::Unlimited;
    whiteTimeMs_ = blackTimeMs_ = incrementMs_ = 0;
    playerColor_ = position.sideToMove();
    flipped_ = playerColor_ == chess::Color::Black;
    cursorSquare_ = position.sideToMove() == chess::Color::White ? chess::parseSquare("e4") : chess::parseSquare("e5");
    selectedSquare_ = chess::NoSquare;
    selectedMoves_.clear();
    lastMove_.reset();
    animation_ = {};
    pendingAutoFlip_ = false;
    promotionChoices_.clear();
    resultFinalized_ = false;
    screen_ = Screen::Game;
}

void App::returnToMainMenu() {
    settingsReturnToGame_ = false;
    engine_.stop();
    screen_ = Screen::MainMenu;
    menuIndex_ = 0;
    selectedSquare_ = chess::NoSquare;
    selectedMoves_.clear();
    promotionChoices_.clear();
    pendingAutoFlip_ = false;
    pendingEngineResult_.reset();
}

void App::selectSquare(int square) {
    const chess::Piece piece = game_.position().pieceAt(square);
    if (!piece || piece.color != game_.position().sideToMove()) {
        sound_.play(platform::SoundEffect::Error);
        return;
    }
    selectedSquare_ = square;
    selectedMoves_ = game_.position().legalMovesFrom(square);
    if (selectedMoves_.empty()) sound_.play(platform::SoundEffect::Error);
}

void App::attemptMoveTo(int square) {
    if (square == selectedSquare_) {
        selectedSquare_ = chess::NoSquare;
        selectedMoves_.clear();
        return;
    }
    std::vector<chess::Move> choices;
    for (const chess::Move& move : selectedMoves_)
        if (move.to == square) choices.push_back(move);

    if (choices.empty()) {
        const chess::Piece piece = game_.position().pieceAt(square);
        if (piece && piece.color == game_.position().sideToMove()) selectSquare(square);
        else sound_.play(platform::SoundEffect::Error);
        return;
    }
    if (choices.size() > 1) {
        promotionChoices_ = choices;
        promotionIndex_ = 0;
        return;
    }

    if (puzzleMode_) {
        const auto& solution = puzzles()[activePuzzle_].solution;
        if (puzzleStep_ >= solution.size() || chess::moveToUci(choices.front()) != solution[puzzleStep_]) {
            sound_.play(platform::SoundEffect::Error);
            showToast(tr("Spróbuj innego ruchu", "Try another move"));
            selectedSquare_ = chess::NoSquare;
            selectedMoves_.clear();
            return;
        }
        ++puzzleStep_;
    }
    playMove(choices.front());
    if (puzzleMode_ && puzzleStep_ >= puzzles()[activePuzzle_].solution.size()) {
        puzzleSolved_ = true;
        sound_.play(platform::SoundEffect::GameEnd);
    }
}

void App::choosePromotion(int index) {
    if (index < 0 || index >= static_cast<int>(promotionChoices_.size())) return;
    const chess::Move move = promotionChoices_[index];
    promotionChoices_.clear();
    if (puzzleMode_) {
        const auto& solution = puzzles()[activePuzzle_].solution;
        if (puzzleStep_ >= solution.size() || chess::moveToUci(move) != solution[puzzleStep_]) {
            sound_.play(platform::SoundEffect::Error);
            showToast(tr("To nie jest rozwiązanie", "That is not the solution"));
            return;
        }
        ++puzzleStep_;
    }
    playMove(move);
    if (puzzleMode_ && puzzleStep_ >= puzzles()[activePuzzle_].solution.size()) {
        puzzleSolved_ = true;
        sound_.play(platform::SoundEffect::GameEnd);
    }
}

void App::playMove(const chess::Move& move, bool) {
    const chess::Position before = game_.position();
    const chess::Piece moving = before.pieceAt(move.from);
    const chess::Color movingSide = before.sideToMove();
    if (!game_.play(move)) {
        sound_.play(platform::SoundEffect::Error);
        return;
    }
    const chess::Move actualMove = game_.history().back().move;
    if (clockEnabled()) {
        if (movingSide == chess::Color::White) whiteTimeMs_ += incrementMs_;
        else blackTimeMs_ += incrementMs_;
    }
    lastMove_ = actualMove;
    selectedSquare_ = chess::NoSquare;
    selectedMoves_.clear();

    if (settings_.animations) {
        animation_.active = true;
        animation_.move = actualMove;
        animation_.piece = moving;
        animation_.progress = 0.0f;
        animationElapsedMs_ = 0.0f;
    }
    if (actualMove.isCastle()) sound_.play(platform::SoundEffect::Castle);
    else if (actualMove.isCapture()) sound_.play(platform::SoundEffect::Capture);
    else sound_.play(platform::SoundEffect::Move);
    if (game_.position().inCheck(game_.position().sideToMove()))
        sound_.play(platform::SoundEffect::Check);

    if (gameMode_ == platform::GameMode::Local && settings_.autoFlipLocal && !puzzleMode_) {
        if (settings_.animations) pendingAutoFlip_ = true;
        else {
            flipped_ = game_.position().sideToMove() == chess::Color::Black;
            pendingAutoFlip_ = false;
        }
    }
    if (!puzzleMode_) saveCurrentGame();
    if (game_.result() != chess::GameResult::Ongoing) finalizeResult();
    else startEngineIfNeeded();
}

void App::undoMove() {
    if (puzzleMode_ || game_.result() != chess::GameResult::Ongoing || game_.history().empty()) {
        sound_.play(platform::SoundEffect::Error);
        return;
    }
    const bool humanTurnBeforeUndo = isHumanTurn();
    engine_.stop();
    pendingEngineResult_.reset();
    const int plies = gameMode_ == platform::GameMode::Cpu && humanTurnBeforeUndo
        && game_.history().size() >= 2 ? 2 : 1;
    if (!game_.undo(plies)) return;
    lastMove_ = game_.history().empty() ? std::optional<chess::Move>{}
                                        : std::optional<chess::Move>{game_.history().back().move};
    animation_ = {};
    pendingAutoFlip_ = false;
    selectedSquare_ = chess::NoSquare;
    selectedMoves_.clear();
    if (gameMode_ == platform::GameMode::Cpu) flipped_ = playerColor_ == chess::Color::Black;
    sound_.play(platform::SoundEffect::Move);
    saveCurrentGame();
    startEngineIfNeeded();
}

bool App::isHumanTurn() const {
    if (puzzleMode_) return !puzzleSolved_ && (puzzleStep_ % 2 == 0);
    return gameMode_ == platform::GameMode::Local || game_.position().sideToMove() == playerColor_;
}

void App::startEngineIfNeeded() {
    if (!engineAvailable_ || puzzleMode_ || screen_ != Screen::Game
        || gameMode_ != platform::GameMode::Cpu || game_.isOver() || isHumanTurn()
        || engine_.isThinking() || pendingEngineResult_) return;

    int thinkTime = engine::StockfishEngine::defaultThinkTimeMsForElo(gameEngineElo_);
    if (clockEnabled()) {
        const std::int64_t remaining = game_.position().sideToMove() == chess::Color::White
            ? whiteTimeMs_ : blackTimeMs_;
        // High-rated presets need enough time to reach useful depth on an Old
        // 3DS. Still scale down automatically when the engine is short on time.
        const std::int64_t clockBudget = std::clamp<std::int64_t>(remaining / 40, 50, 8000);
        thinkTime = std::min<int>(thinkTime, static_cast<int>(clockBudget));
    }
    platform::writeRuntimeStage("stockfish_search");
    if (!engine_.start(game_.position().toFen(), gameEngineElo_, thinkTime)) {
        platform::writeRuntimeStage("running");
        showToast(tr("Błąd uruchamiania silnika", "Engine start error"));
    }
}

bool App::ensureEngineAvailable() {
    if (engine_.isInitialized()) return true;
    if (!engineAvailable_) return false;
    platform::writeRuntimeStage("stockfish_init");
    engineAvailable_ = engine_.initialize();
    platform::writeRuntimeStage(engineAvailable_ ? "running" : "stockfish_failed");
    return engineAvailable_;
}

void App::applyEngineResult(const engine::EngineResult& result) {
    if (game_.result() != chess::GameResult::Ongoing || isHumanTurn()) return;
    chess::Move move;
    if (!game_.position().findLegalMoveUci(result.bestMoveUci, move)) {
        showToast(tr("Stockfish zwrócił błędny ruch", "Stockfish returned an invalid move"));
        return;
    }
    lastEvaluationCp_ = result.evaluationCp;
    lastEngineDepth_ = result.depth;
    playMove(move, true);
}

void App::update(float deltaMs, std::uint64_t nowMs) {
    if (!toast_.empty() && nowMs >= toastUntil_) toast_.clear();
    if (screen_ != Screen::Game) return;

    if (game_.result() == chess::GameResult::Ongoing && clockEnabled()) {
        std::int64_t& clock = activeClock();
        clock = std::max<std::int64_t>(0, clock - static_cast<std::int64_t>(deltaMs));
        if (clock == 0) {
            engine_.stop();
            game_.timeout(game_.position().sideToMove());
            finalizeResult();
        }
    }

    if (animation_.active) {
        animationElapsedMs_ += deltaMs;
        animation_.progress = std::min(1.0f, animationElapsedMs_ / 165.0f);
        if (animation_.progress >= 1.0f) {
            animation_.active = false;
            if (pendingAutoFlip_) {
                flipped_ = game_.position().sideToMove() == chess::Color::Black;
                pendingAutoFlip_ = false;
            }
        }
    }

    engine::EngineResult result;
    if (engine_.poll(result)) {
        platform::writeRuntimeStage("running");
        pendingEngineResult_ = result;
    }
    if (pendingEngineResult_ && !animation_.active) {
        const engine::EngineResult completed = *pendingEngineResult_;
        pendingEngineResult_.reset();
        applyEngineResult(completed);
    }

    if (puzzleMode_ && !puzzleSolved_ && puzzleStep_ % 2 == 1 && !animation_.active) {
        const auto& solution = puzzles()[activePuzzle_].solution;
        if (puzzleStep_ < solution.size()) {
            chess::Move reply;
            if (game_.position().findLegalMoveUci(solution[puzzleStep_], reply)) {
                ++puzzleStep_;
                playMove(reply);
                if (puzzleStep_ >= solution.size()) puzzleSolved_ = true;
            }
        }
    }
    startEngineIfNeeded();
}

bool App::clockEnabled() const { return timeControl_ != platform::TimeControl::Unlimited; }

std::int64_t& App::activeClock() {
    return game_.position().sideToMove() == chess::Color::White ? whiteTimeMs_ : blackTimeMs_;
}

void App::saveCurrentGame() {
    if (puzzleMode_ || game_.result() != chess::GameResult::Ongoing) return;
    platform::SavedGame saved;
    saved.mode = gameMode_;
    saved.timeControl = timeControl_;
    saved.playerColor = playerColor_;
    saved.engineElo = gameEngineElo_;
    saved.whiteTimeMs = whiteTimeMs_;
    saved.blackTimeMs = blackTimeMs_;
    saved.incrementMs = incrementMs_;
    saved.initialFen = game_.initialFen();
    saved.moves = game_.uciHistory();
    if (storage_.saveGame(saved)) hasSavedGame_ = true;
}

void App::finalizeResult() {
    if (resultFinalized_ || game_.result() == chess::GameResult::Ongoing) return;
    resultFinalized_ = true;
    engine_.stop();
    if (puzzleMode_) return;

    const chess::GameResult result = game_.result();
    if (gameMode_ == platform::GameMode::Cpu) {
        if (isDraw(result)) ++statistics_.cpuDraws;
        else if (winner(result) == playerColor_) {
            ++statistics_.cpuWins;
            statistics_.highestDefeatedElo = std::max(statistics_.highestDefeatedElo, gameEngineElo_);
        } else ++statistics_.cpuLosses;
    } else ++statistics_.localGames;
    storage_.clearSavedGame();
    hasSavedGame_ = false;
    exportCurrentPgn();
    storage_.saveStatistics(statistics_);
    sound_.play(platform::SoundEffect::GameEnd);
}

void App::exportCurrentPgn() {
    std::string white = "White";
    std::string black = "Black";
    if (gameMode_ == platform::GameMode::Cpu) {
        const std::string stockfish = "Stockfish 11 (" + std::to_string(gameEngineElo_) + " Elo)";
        if (playerColor_ == chess::Color::White) white = "Player", black = stockfish;
        else white = stockfish, black = "Player";
    }
    if (storage_.exportPgn(game_.toPgn(white, black), statistics_, &lastPgnPath_)) {
        storage_.saveStatistics(statistics_);
        showToast(tr("Zapisano ", "Saved ") + basenameOf(lastPgnPath_), 2600);
    } else showToast(tr("Nie udało się zapisać PGN", "Could not save PGN"));
}

void App::showToast(const std::string& value, std::uint64_t durationMs) {
    toast_ = value;
    toastUntil_ = osGetTime() + durationMs;
}

std::string App::clockText(std::int64_t milliseconds) const {
    if (!clockEnabled()) return "--:--";
    milliseconds = std::max<std::int64_t>(0, milliseconds);
    const int totalSeconds = static_cast<int>((milliseconds + 999) / 1000);
    char buffer[16];
    std::snprintf(buffer, sizeof(buffer), "%02d:%02d", totalSeconds / 60, totalSeconds % 60);
    return buffer;
}

std::string App::tr(const char* polish, const char* english) const {
    return settings_.language == platform::Language::Polish ? polish : english;
}

std::string App::themeName(platform::Theme theme) const {
    switch (theme) {
        case platform::Theme::Classic: return tr("Zielony", "Chess Green");
        case platform::Theme::Midnight: return tr("Niebieski", "Blue");
        case platform::Theme::Forest: return tr("Leśny", "Forest");
        case platform::Theme::Rosewood: return tr("Brązowy", "Brown");
        case platform::Theme::Count: break;
    }
    return "-";
}

std::string App::timeControlName(platform::TimeControl control) const {
    if (control == platform::TimeControl::Unlimited) return tr("Bez zegara", "No clock");
    return platform::clockPreset(control).label;
}

std::string App::sideName(int side) const {
    if (side == 0) return tr("Białe", "White");
    if (side == 1) return tr("Czarne", "Black");
    return tr("Losowo", "Random");
}

std::string App::resultText(chess::GameResult result) const {
    switch (result) {
        case chess::GameResult::Ongoing:
            return tr("Partia trwa", "Game in progress");
        case chess::GameResult::WhiteCheckmate:
            return tr("Białe wygrywają przez mata", "White wins by checkmate");
        case chess::GameResult::BlackCheckmate:
            return tr("Czarne wygrywają przez mata", "Black wins by checkmate");
        case chess::GameResult::DrawStalemate:
            return tr("Remis przez pata", "Draw by stalemate");
        case chess::GameResult::DrawRepetition:
            return tr("Remis przez powtórzenie", "Draw by repetition");
        case chess::GameResult::DrawFiftyMove:
            return tr("Remis przez regułę 50 ruchów", "Draw by 50-move rule");
        case chess::GameResult::DrawInsufficientMaterial:
            return tr("Remis: brak materiału", "Draw: insufficient material");
        case chess::GameResult::WhiteResigned:
            return tr("Czarne wygrywają — poddanie", "Black wins by resignation");
        case chess::GameResult::BlackResigned:
            return tr("Białe wygrywają — poddanie", "White wins by resignation");
        case chess::GameResult::WhiteTimeout:
            return tr("Czarne wygrywają na czas", "Black wins on time");
        case chess::GameResult::BlackTimeout:
            return tr("Białe wygrywają na czas", "White wins on time");
    }
    return tr("Koniec partii", "Game over");
}

void App::render(std::uint64_t) {
    renderer_.beginFrame();
    switch (screen_) {
        case Screen::MainMenu: renderMainMenu(); break;
        case Screen::Setup: renderSetup(); break;
        case Screen::Game: renderGame(); break;
        case Screen::Pause: renderPause(); break;
        case Screen::Settings: renderSettings(); break;
        case Screen::Statistics: renderStatistics(); break;
        case Screen::Puzzles: renderPuzzles(); break;
        case Screen::About: renderAbout(); break;
    }
    renderer_.endFrame();
}

void App::renderMainMenu() {
    const Palette colors = Renderer::palette(settings_.theme);

    renderer_.beginTop(colors.background);
    renderer_.logo(65, 78, 88, colors);
    renderer_.text("Chess3DS", 122, 42, 1.02f, colors.text);
    renderer_.text(tr("Szachy w stylu nowoczesnej aplikacji", "Modern chess, made for 3DS"),
                   124, 82, 0.46f, colors.muted);
    renderer_.panel({122, 116, 246, 62}, colors.panel, 8);
    renderer_.text(tr("Graj z botem", "Play a bot"), 138, 126, 0.48f, colors.text);
    renderer_.text(std::to_string(settings_.engineElo) + " ELO  •  Stockfish 11",
                   138, 151, 0.42f, colors.accent);
    renderer_.text(tr("Zadania  •  gra lokalna  •  offline",
                      "Puzzles  •  local play  •  offline"),
                   200, 197, 0.40f, colors.muted, C2D_AlignCenter);
    renderer_.text(tr("A wybierz   START wyjdź", "A select   START exit"),
                   200, 218, 0.36f, colors.muted, C2D_AlignCenter);

    renderer_.beginBottom(colors.background);
    const auto actions = mainActions();
    for (int i = 0; i < static_cast<int>(actions.size()); ++i) {
        std::string label;
        std::string hint;
        bool disabled = false;
        switch (actions[i]) {
            case MainAction::Continue:
                label = tr("Kontynuuj", "Continue");
                hint = tr("ZAPIS", "SAVE");
                break;
            case MainAction::Cpu:
                label = tr("Graj z botem", "Play Bot");
                hint = std::to_string(settings_.engineElo);
                disabled = !engineAvailable_;
                break;
            case MainAction::Local:
                label = tr("Dwóch graczy", "Two Players");
                hint = "2P";
                break;
            case MainAction::Puzzles:
                label = tr("Zadania", "Puzzles");
                hint = std::to_string(puzzles().size());
                break;
            case MainAction::Settings:
                label = tr("Ustawienia", "Settings");
                break;
            case MainAction::Statistics:
                label = tr("Statystyki", "Stats");
                hint = std::to_string(statistics_.cpuWins) + "W";
                break;
            case MainAction::About:
                label = tr("O grze", "About");
                hint = "v1.5.1";
                break;
            case MainAction::Exit:
                label = tr("Wyjdź", "Exit");
                hint = "START";
                break;
        }
        renderer_.button(gridButtonRect(i), label, i == menuIndex_, disabled, colors, hint);
    }
}

void App::renderSetup() {
    const Palette colors = Renderer::palette(settings_.theme);

    renderer_.beginTop(colors.background);
    renderer_.text(setupMode_ == platform::GameMode::Cpu
        ? tr("Graj z botem", "Play a Bot")
        : tr("Gra lokalna", "Local Game"),
        24, 20, 0.86f, colors.text);

    if (setupMode_ == platform::GameMode::Cpu) {
        renderer_.piece({chess::PieceType::Knight, chess::Color::Black}, 270, 26, 88);
        renderer_.text("Stockfish 11", 24, 70, 0.48f, colors.muted);
        renderer_.text(std::to_string(settings_.engineElo), 24, 101, 1.16f, colors.text);
        renderer_.text("ELO", 135, 123, 0.42f, colors.accent);
        renderer_.panel({24, 166, 210, 42}, colors.panel, 7);
        renderer_.text(tr("← / → zmienia ranking o 100",
                          "← / → changes rating by 100"),
                       36, 178, 0.39f, colors.muted);
    } else {
        renderer_.piece({chess::PieceType::King, chess::Color::White}, 90, 63, 92);
        renderer_.piece({chess::PieceType::King, chess::Color::Black}, 218, 63, 92);
        renderer_.text(tr("Jedna konsola, dwóch graczy",
                          "One console, two players"),
                       200, 181, 0.46f, colors.muted, C2D_AlignCenter);
    }

    renderer_.text(tr("B wróć", "B back"), 376, 216, 0.36f, colors.muted, C2D_AlignRight);

    renderer_.beginBottom(colors.background);
    std::vector<std::pair<std::string, std::string>> rows;
    if (setupMode_ == platform::GameMode::Cpu) {
        rows.push_back({tr("Kolor", "Side"), sideName(setupSide_)});
        rows.push_back({tr("Tempo", "Clock"), timeControlName(setupTimeControl_)});
        rows.push_back({tr("Ranking przeciwnika", "Opponent rating"),
                        std::to_string(settings_.engineElo) + " ELO"});
    } else {
        rows.push_back({tr("Tempo", "Clock"), timeControlName(setupTimeControl_)});
    }
    rows.push_back({tr("Rozpocznij", "Start Game"), "A"});
    rows.push_back({tr("Wróć", "Back"), "B"});

    for (int i = 0; i < static_cast<int>(rows.size()); ++i)
        renderer_.button(listButtonRect(i, 36.0f, 18.0f), rows[i].first,
                         i == setupIndex_, false, colors, rows[i].second);
}

void App::renderSettings() {
    const Palette colors = Renderer::palette(settings_.theme);

    renderer_.beginTop(colors.background);
    renderer_.text(tr("Ustawienia", "Settings"), 24, 22, 0.88f, colors.text);
    renderer_.text(tr("Wygląd i zachowanie gry", "Appearance and game behavior"),
                   24, 62, 0.44f, colors.muted);

    renderer_.panel({24, 100, 352, 78}, colors.panel, 8);
    renderer_.piece({chess::PieceType::Queen, chess::Color::White}, 39, 111, 56);
    renderer_.text(themeName(settings_.theme), 108, 113, 0.56f, colors.text);
    renderer_.text(std::to_string(settings_.engineElo) + " ELO",
                   108, 145, 0.43f, colors.accent);
    renderer_.text(tr("Domyślny bot", "Default bot"),
                   364, 145, 0.38f, colors.muted, C2D_AlignRight);
    renderer_.text(tr("B zapisuje i wraca", "B saves and returns"),
                   24, 210, 0.38f, colors.muted);

    renderer_.beginBottom(colors.background);
    const auto onOff = [&](bool value) { return value ? tr("Tak", "On") : tr("Nie", "Off"); };
    const std::array<std::pair<std::string, std::string>, 8> rows{{
        {tr("Ranking bota", "Bot rating"), std::to_string(settings_.engineElo) + " ELO"},
        {tr("Motyw planszy", "Board theme"), themeName(settings_.theme)},
        {tr("Język", "Language"), settings_.language == platform::Language::Polish ? "Polski" : "English"},
        {tr("Dźwięki", "Sound"), onOff(settings_.sound)},
        {tr("Legalne ruchy", "Legal moves"), onOff(settings_.showLegalMoves)},
        {tr("Animacje", "Animations"), onOff(settings_.animations)},
        {tr("Auto-obrót lokalnie", "Auto-flip local"), onOff(settings_.autoFlipLocal)},
        {tr("Wróć", "Back"), "B"},
    }};
    for (int i = 0; i < 8; ++i)
        renderer_.button(listButtonRect(i, 24.0f, 4.0f), rows[i].first,
                         i == settingsIndex_, false, colors, rows[i].second);
}

void App::renderStatistics() {
    const Palette colors = Renderer::palette(settings_.theme);
    const std::uint32_t total = statistics_.cpuWins + statistics_.cpuLosses + statistics_.cpuDraws;
    const float ratio = total ? static_cast<float>(statistics_.cpuWins) / total : 0.0f;

    renderer_.beginTop(colors.background);
    renderer_.text(tr("Statystyki", "Statistics"), 24, 22, 0.88f, colors.text);
    renderer_.panel({24, 78, 352, 100}, colors.panel, 8);
    renderer_.text(tr("Wygrane z botami", "Wins vs bots"), 42, 92, 0.42f, colors.muted);
    renderer_.text(std::to_string(statistics_.cpuWins), 42, 120, 0.92f, colors.text);
    renderer_.progressBar({146, 129, 208, 13}, ratio, colors.panelAlt, colors.accent);
    renderer_.text(std::to_string(static_cast<int>(ratio * 100.0f)) + "%",
                   354, 151, 0.39f, colors.accent, C2D_AlignRight);
    renderer_.text(tr("B menu", "B menu"), 376, 213, 0.36f, colors.muted, C2D_AlignRight);

    renderer_.beginBottom(colors.background);
    const std::array<std::pair<std::string, std::string>, 6> rows{{
        {tr("Wygrane", "Wins"), std::to_string(statistics_.cpuWins)},
        {tr("Przegrane", "Losses"), std::to_string(statistics_.cpuLosses)},
        {tr("Remisy", "Draws"), std::to_string(statistics_.cpuDraws)},
        {tr("Partie lokalne", "Local games"), std::to_string(statistics_.localGames)},
        {tr("Najwyższy pokonany ELO", "Highest defeated ELO"),
         statistics_.highestDefeatedElo ? std::to_string(statistics_.highestDefeatedElo) : "-"},
        {tr("Wyeksportowane PGN", "Exported PGNs"), std::to_string(statistics_.exportedGames)},
    }};
    for (int i = 0; i < 6; ++i)
        renderer_.button(listButtonRect(i, 30.0f, 12.0f), rows[i].first,
                         false, false, colors, rows[i].second);
}

void App::renderPuzzles() {
    const Palette colors = Renderer::palette(settings_.theme);

    renderer_.beginTop(colors.background);
    renderer_.text(tr("Zadania", "Puzzles"), 24, 22, 0.88f, colors.text);
    renderer_.piece({chess::PieceType::Knight, chess::Color::White}, 250, 45, 104);
    renderer_.panel({24, 87, 205, 84}, colors.panel, 8);
    renderer_.text(tr("Znajdź mata", "Find the mate"), 38, 101, 0.52f, colors.text);
    renderer_.text(tr("5 krótkich pozycji\nbez podpowiedzi silnika",
                      "5 short positions\nwithout engine hints"),
                   38, 132, 0.40f, colors.muted, 0, 175);
    renderer_.text(tr("B menu", "B menu"), 376, 213, 0.36f, colors.muted, C2D_AlignRight);

    renderer_.beginBottom(colors.background);
    for (int i = 0; i < static_cast<int>(puzzles().size()); ++i) {
        const Puzzle& puzzle = puzzles()[i];
        renderer_.button(listButtonRect(i, 28.0f, 8.0f),
            settings_.language == platform::Language::Polish ? puzzle.titlePl : puzzle.titleEn,
            i == puzzleIndex_, false, colors, tr("MAT", "MATE"));
    }
    const int back = static_cast<int>(puzzles().size());
    renderer_.button(listButtonRect(back, 28.0f, 8.0f), tr("Wróć", "Back"),
                     back == puzzleIndex_, false, colors, "B");
}

void App::renderAbout() {
    const Palette colors = Renderer::palette(settings_.theme);

    renderer_.beginTop(colors.background);
    renderer_.logo(67, 78, 88, colors);
    renderer_.text("Chess3DS", 122, 43, 0.96f, colors.text);
    renderer_.text("v1.5.1", 124, 82, 0.44f, colors.accent);
    renderer_.text("mexo4", 124, 110, 0.42f, colors.muted);
    renderer_.panel({24, 164, 352, 45}, colors.panel, 7);
    renderer_.text(tr("Własny interfejs inspirowany nowoczesnymi serwisami szachowymi.",
                      "Original UI inspired by modern online chess clients."),
                   38, 176, 0.38f, colors.muted, 0, 322);
    renderer_.text(tr("B menu", "B menu"), 376, 215, 0.36f, colors.muted, C2D_AlignRight);

    renderer_.beginBottom(colors.background);
    renderer_.panel({12, 12, 296, 216}, colors.panel, 7);
    renderer_.text(tr("Silnik: Stockfish 11 (GPLv3)\n"
                      "Figury: zestaw Classic/Neo inspirowany nowoczesnymi klientami\n"
                      "Plansza: zielony motyw 2D\n\n"
                      "Sterowanie:\n"
                      "A / dotyk — wybór i ruch\n"
                      "B / START — pauza\n"
                      "Y — cofnij ruch\n"
                      "X — obróć planszę\n\n"
                      "github.com/mexo4/Chess3ds",
                      "Engine: Stockfish 11 (GPLv3)\n"
                      "Pieces: original Classic/Neo vector set\n"
                      "Board: green 2D theme\n\n"
                      "Controls:\n"
                      "A / touch — select and move\n"
                      "B / START — pause\n"
                      "Y — undo\n"
                      "X — flip board\n\n"
                      "github.com/mexo4/Chess3ds"),
                   24, 22, 0.40f, colors.text, 0, 272);
}

void App::renderGame() {
    // v1.5.1 deliberately locks the gameplay screen to the approved Concept A
    // visual language. Other themes still apply to menus/settings.
    const Palette colors = Renderer::palette(platform::Theme::Classic);
    const chess::Color topColor = gameMode_ == platform::GameMode::Cpu
        ? (playerColor_ == chess::Color::White ? chess::Color::Black : chess::Color::White)
        : chess::Color::Black;
    const chess::Color bottomColor = gameMode_ == platform::GameMode::Cpu
        ? playerColor_ : chess::Color::White;

    const auto isActive = [&](chess::Color color) {
        return game_.position().sideToMove() == color
            && game_.result() == chess::GameResult::Ongoing;
    };
    const auto timeFor = [&](chess::Color color) {
        return color == chess::Color::White ? whiteTimeMs_ : blackTimeMs_;
    };
    const auto nameFor = [&](chess::Color color) {
        if (puzzleMode_) return color == playerColor_ ? tr("Ty", "You") : tr("Pozycja", "Puzzle");
        if (gameMode_ == platform::GameMode::Local)
            return color == chess::Color::White ? tr("Białe", "White") : tr("Czarne", "Black");
        return color == playerColor_ ? tr("Ty", "You") : std::string("Stockfish");
    };
    const auto subtitleFor = [&](chess::Color color) {
        if (gameMode_ == platform::GameMode::Cpu && !puzzleMode_ && color != playerColor_)
            return std::to_string(gameEngineElo_) + " ELO";
        return color == chess::Color::White ? tr("Białe", "White") : tr("Czarne", "Black");
    };

    // -------------------------------------------------------------------------
    // TOP SCREEN — board left, player/timer stack right, matching Concept A.
    // -------------------------------------------------------------------------
    renderer_.beginTop(colors.background);

    constexpr float boardX = 14.0f;
    constexpr float boardY = 4.0f;
    constexpr float square = 27.1f;
    renderer_.boardAt(game_.position(), colors, flipped_, cursorSquare_, selectedSquare_,
                      selectedMoves_, lastMove_ ? &*lastMove_ : nullptr, animation_,
                      settings_.showLegalMoves, boardX, boardY, square);

    const float sideX = 239.5f;
    const float sideW = 156.0f;
    const std::uint32_t ivory = C2D_Color32(239, 229, 204, 255);
    const std::uint32_t ivoryText = C2D_Color32(33, 33, 31, 255);
    const std::uint32_t blackCard = C2D_Color32(27, 28, 26, 255);
    const std::uint32_t blackCardAlt = C2D_Color32(36, 37, 34, 255);

    const auto avatar = [&](float x, float y, chess::Color color) {
        const bool white = color == chess::Color::White;
        const std::uint32_t bg = white ? ivory : C2D_Color32(46, 47, 44, 255);
        const std::uint32_t fg = white ? C2D_Color32(252, 250, 241, 255)
                                       : C2D_Color32(12, 13, 12, 255);
        renderer_.panel({x, y, 31, 31}, bg, 4);
        C2D_DrawCircleSolid(x + 15.5f, y + 10.2f, 0.72f, 5.8f, fg);
        C2D_DrawEllipseSolid(x + 7.0f, y + 16.0f, 0.72f, 17.0f, 11.0f, fg);
    };

    const auto playerCard = [&](float y, chess::Color color) {
        renderer_.panel({sideX, y, sideW, 40}, blackCard, 6);
        if (isActive(color))
            C2D_DrawRectSolid(sideX, y + 5, 0.74f, 3.0f, 30.0f, colors.accent);
        avatar(sideX + 6, y + 4, color);
        renderer_.text(nameFor(color), sideX + 44, y + 5, 0.38f, colors.text);
        renderer_.text(subtitleFor(color), sideX + 44, y + 23, 0.28f,
                       gameMode_ == platform::GameMode::Cpu && color != playerColor_
                           ? colors.accent : colors.muted);
    };

    const auto clockCard = [&](float y, chess::Color color) {
        const bool white = color == chess::Color::White;
        const std::uint32_t fill = white ? ivory : blackCardAlt;
        const std::uint32_t fg = white ? ivoryText : colors.text;
        renderer_.panel({sideX, y, sideW, 44}, fill, 6);
        // small clock glyph
        C2D_DrawCircleSolid(sideX + 20.0f, y + 22.0f, 0.70f, 8.0f, fg);
        C2D_DrawCircleSolid(sideX + 20.0f, y + 22.0f, 0.71f, 5.6f, fill);
        C2D_DrawLine(sideX + 20.0f, y + 22.0f, fg,
                     sideX + 20.0f, y + 17.0f, fg, 1.3f, 0.73f);
        C2D_DrawLine(sideX + 20.0f, y + 22.0f, fg,
                     sideX + 24.0f, y + 22.0f, fg, 1.3f, 0.73f);
        renderer_.text(clockText(timeFor(color)), sideX + sideW - 9, y + 9, 0.61f,
                       fg, C2D_AlignRight);
    };

    playerCard(4, topColor);
    clockCard(48, topColor);

    renderer_.panel({sideX, 97, sideW, 42}, blackCard, 6);
    C2D_DrawCircleSolid(sideX + 13, 111, 0.72f, 3.0f, colors.accent);
    renderer_.text(tr("Ostatni ruch", "Last move"), sideX + 23, 103, 0.27f, colors.muted);
    std::string lastMoveText = "-";
    if (!game_.history().empty()) lastMoveText = game_.history().back().san;
    renderer_.text(lastMoveText, sideX + 13, 119, 0.40f, colors.text);
    if (gameMode_ == platform::GameMode::Cpu && !puzzleMode_ && lastEngineDepth_ > 0) {
        std::ostringstream engineInfo;
        engineInfo << "d" << lastEngineDepth_;
        renderer_.text(engineInfo.str(), sideX + sideW - 9, 121, 0.25f,
                       colors.accent, C2D_AlignRight);
    }

    clockCard(144, bottomColor);
    playerCard(192, bottomColor);

    if (!toast_.empty()) {
        renderer_.panel({sideX + 4, 174, sideW - 8, 15}, C2D_Color32(16, 17, 16, 235), 3);
        renderer_.text(toast_, sideX + sideW * 0.5f, 177, 0.21f,
                       colors.text, C2D_AlignCenter);
    }

    // -------------------------------------------------------------------------
    // BOTTOM SCREEN — the reference's piece gallery and five touch buttons.
    // -------------------------------------------------------------------------
    renderer_.beginBottom(C2D_Color32(22, 23, 22, 255));
    renderer_.panel({5, 5, 310, 166}, C2D_Color32(29, 30, 28, 255), 7);

    C2D_DrawLine(111, 17, C2D_Color32(93, 119, 52, 255),
                 139, 17, C2D_Color32(93, 119, 52, 255), 1.0f, 0.72f);
    C2D_DrawLine(181, 17, C2D_Color32(93, 119, 52, 255),
                 209, 17, C2D_Color32(93, 119, 52, 255), 1.0f, 0.72f);
    renderer_.text("PIECE GALLERY", 160, 9, 0.29f, colors.accent, C2D_AlignCenter);

    C2D_DrawLine(160, 30, C2D_Color32(100, 100, 94, 180),
                 160, 151, C2D_Color32(100, 100, 94, 180), 1.0f, 0.72f);
    renderer_.text(tr("BIAŁE", "WHITE"), 81, 31, 0.21f, colors.muted, C2D_AlignCenter);
    renderer_.text(tr("CZARNE", "BLACK"), 239, 31, 0.21f, colors.muted, C2D_AlignCenter);

    const std::array<chess::PieceType, 6> galleryTypes{{
        chess::PieceType::King, chess::PieceType::Queen, chess::PieceType::Rook,
        chess::PieceType::Bishop, chess::PieceType::Knight, chess::PieceType::Pawn
    }};
    const std::array<const char*, 6> galleryLabels{{"K", "Q", "R", "B", "N", "P"}};
    const auto galleryHalf = [&](float startX, chess::Color color) {
        for (int i = 0; i < 6; ++i) {
            const float cellW = 25.0f;
            const float x = startX + i * cellW;
            renderer_.piece({galleryTypes[i], color}, x + 1.0f, 50.0f, 25.0f);
            renderer_.text(galleryLabels[i], x + 13.0f, 79.0f, 0.20f,
                           colors.muted, C2D_AlignCenter);
        }
    };
    galleryHalf(6.0f, chess::Color::White);
    galleryHalf(164.0f, chess::Color::Black);

    renderer_.text(tr("Król  Hetman  Wieża  Goniec  Skoczek  Pion",
                      "King  Queen  Rook  Bishop  Knight  Pawn"),
                   80, 105, 0.17f, colors.muted, C2D_AlignCenter, 146);
    renderer_.text(tr("Król  Hetman  Wieża  Goniec  Skoczek  Pion",
                      "King  Queen  Rook  Bishop  Knight  Pawn"),
                   239, 105, 0.17f, colors.muted, C2D_AlignCenter, 146);

    const std::array<std::string, 5> buttons{{
        tr("MENU", "MENU"), tr("COFNIJ", "UNDO"), tr("PODP.", "HINT"),
        tr("OPCJE", "SETTINGS"), tr("PODDAJ", "RESIGN")
    }};
    for (int i = 0; i < 5; ++i) {
        const Rect r = gameTouchButtonRect(i);
        const bool hint = i == 2;
        renderer_.panel({r.x, r.y + 3, r.w, r.h}, C2D_Color32(10, 10, 10, 220), 6);
        if (hint) {
            renderer_.panel(r, colors.accent, 6);
            renderer_.panel({r.x + 1.4f, r.y + 1.4f, r.w - 2.8f, r.h - 2.8f},
                            C2D_Color32(31, 32, 30, 255), 5);
        } else {
            renderer_.panel(r, C2D_Color32(35, 36, 34, 255), 6);
        }
        renderer_.text(buttons[i], r.x + r.w * 0.5f, r.y + 15, 0.25f,
                       hint ? colors.accent : colors.text, C2D_AlignCenter);
    }

    if (!promotionChoices_.empty()) {
        renderer_.panel({42, 64, 236, 90}, colors.background, 9);
        renderer_.text(tr("Wybierz figurę", "Choose Piece"), 160, 72, 0.42f,
                       colors.text, C2D_AlignCenter);
        for (int i = 0; i < static_cast<int>(promotionChoices_.size()); ++i) {
            const Rect rect{55.0f + i * 53.0f, 100.0f, 46.0f, 50.0f};
            renderer_.panel(rect, i == promotionIndex_ ? colors.accent : colors.panel, 5);
            renderer_.piece({promotionChoices_[i].promotion, game_.position().sideToMove()},
                            rect.x + 8, rect.y + 5, 36);
        }
    }

    if (puzzleSolved_ || game_.result() != chess::GameResult::Ongoing) {
        renderer_.panel({34, 55, 252, 116}, colors.background, 10);
        renderer_.text(puzzleSolved_ ? tr("Rozwiązane!", "Solved!")
                                     : resultText(game_.result()),
                       160, 72, 0.56f, colors.accent, C2D_AlignCenter);
        renderer_.text(puzzleMode_ ? tr("A następne   B menu", "A next   B menu")
                                   : tr("A rewanż   B menu", "A rematch   B menu"),
                       160, 140, 0.40f, colors.text, C2D_AlignCenter);
    }
}

void App::renderPause() {
    const Palette colors = Renderer::palette(settings_.theme);

    renderer_.beginTop(colors.background);
    renderer_.logo(73, 82, 84, colors);
    renderer_.text(tr("Pauza", "Paused"), 128, 50, 0.92f, colors.text);
    renderer_.text(tr("Partia jest zatrzymana", "Game is paused"),
                   130, 91, 0.43f, colors.muted);
    renderer_.panel({130, 126, 220, 50}, colors.panel, 7);
    renderer_.text(gameMode_ == platform::GameMode::Cpu
        ? std::string("Stockfish  ") + std::to_string(gameEngineElo_) + " ELO"
        : tr("Gra lokalna", "Local game"),
        146, 141, 0.42f, colors.accent);

    renderer_.beginBottom(colors.background);
    const std::array<std::string, 4> rows{{
        tr("Wznów", "Resume"),
        tr("Zapisz i wróć", "Save and Return"),
        tr("Poddaj partię", "Resign"),
        tr("Eksportuj PGN", "Export PGN")
    }};
    for (int i = 0; i < 4; ++i)
        renderer_.button(listButtonRect(i, 38.0f, 24.0f), rows[i],
                         i == menuIndex_, false, colors);
    if (!toast_.empty())
        renderer_.text(toast_, 160, 206, 0.38f, colors.accent, C2D_AlignCenter);
}

const std::vector<App::Puzzle>& App::puzzles() {
    static const std::vector<Puzzle> values{
        {"Mat hetmanem", "Queen mate", "7k/5Q2/6K1/8/8/8/8/8 w - - 0 1", {"f7g7"}},
        {"Mat na ostatniej linii", "Back-rank mate", "6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1", {"d1d8"}},
        {"Zamknięty król", "Boxed-in king", "7k/6pp/5Q2/8/8/8/8/6K1 w - - 0 1", {"f6f8"}},
        {"Mat skoczkiem", "Knight mate", "6rk/6pp/7N/8/8/8/8/6K1 w - - 0 1", {"h6f7"}},
        {"Promocja z matem", "Promotion mate", "7k/5Ppp/4K3/8/8/8/8/8 w - - 0 1", {"f7f8q"}},
    };
    return values;
}

} // namespace chess3ds::ui
